# Ptasia Mapa 0.6.1 — Obserwacje ptaków

To jest dopisana wersja do Twojego projektu 0.6.0.

## Co doszło

- jedna aplikacja, bez osobnego projektu,
- zakładka **Ptaki** z oddzielną mapą obserwacji,
- zakładka **Dodaj** do dodawania własnej obserwacji,
- import z publicznej strony Clanga,
- potwierdzanie obserwacji przez innych użytkowników,
- status ptaka: nadal jest / nie ma / nie wiadomo,
- panel admina dla ptaków wrażliwych,
- uprawnienia po emailu: dostęp do wszystkich albo tylko wybranych gatunków.

## Jak działa ukrywanie ptaków wrażliwych

Dla zwykłego użytkownika aplikacja pokazuje punkt przybliżony.
Dokładny GPS jest zapisywany w osobnej tabeli:

`bird_observation_exact_locations`

Dostęp do dokładnych punktów dostają tylko:

- admin,
- super admin,
- użytkownik z wpisem w `bird_sensitive_access`, np. `email + Bielik`,
- użytkownik z wpisem `email + *`, czyli wszystkie gatunki wrażliwe.

## Co trzeba zrobić w Supabase

Wklej i uruchom aktualny plik:

`supabase/schema.sql`

## Uwaga o Clanga

Clanga nie wygląda jak stabilne publiczne API. Import jest parserem HTML.
Jeśli strona zmieni układ, parser może wymagać poprawki.
