
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:html/parser.dart' as html_parser;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:uuid/uuid.dart';

const String supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const String supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
const String adminPassword = String.fromEnvironment('ADMIN_PASSWORD', defaultValue: 'ptasia-admin');
const String superAdminEmail = String.fromEnvironment('SUPER_ADMIN_EMAIL', defaultValue: 'bartoszlawicki@gmail.com');
const String oauthRedirectTo = String.fromEnvironment(
  'SUPABASE_OAUTH_REDIRECT_TO',
  defaultValue: 'io.supabase.flutter://login-callback/',
);
const String passwordResetRedirectTo = String.fromEnvironment(
  'SUPABASE_PASSWORD_RESET_REDIRECT_TO',
  defaultValue: 'io.supabase.flutter://reset-password/',
);

final GlobalKey<NavigatorState> ptasiaNavigatorKey = GlobalKey<NavigatorState>();

const String appVersionName = String.fromEnvironment('APP_VERSION_NAME', defaultValue: '0.6.1');
const int appVersionCode = int.fromEnvironment('APP_VERSION_CODE', defaultValue: 61);
const String appUpdateJsonUrl = String.fromEnvironment('APP_UPDATE_JSON_URL');
const String appUpdateApkUrl = String.fromEnvironment('APP_UPDATE_APK_URL');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  bool supabaseReady = false;
  final cleanUrl = _normalizeSupabaseUrl(supabaseUrl);

  if (cleanUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    try {
      await Supabase.initialize(
        url: cleanUrl,
        anonKey: supabaseAnonKey,
        authOptions: const FlutterAuthClientOptions(
          authFlowType: AuthFlowType.pkce,
        ),
      );
      supabaseReady = true;
    } catch (_) {
      supabaseReady = false;
    }
  }

  runApp(PtasiaApp(supabaseReady: supabaseReady));
}

String _normalizeSupabaseUrl(String raw) {
  var url = raw.trim();
  if (url.isEmpty) return '';
  while (url.endsWith('/')) {
    url = url.substring(0, url.length - 1);
  }
  url = url.replaceAll('/rest/v1', '');
  url = url.replaceAll('/auth/v1', '');
  return url;
}

class PtasiaApp extends StatefulWidget {
  const PtasiaApp({super.key, required this.supabaseReady});

  final bool supabaseReady;

  @override
  State<PtasiaApp> createState() => _PtasiaAppState();
}

class _PtasiaAppState extends State<PtasiaApp> {
  late final AppState state;

  @override
  void initState() {
    super.initState();
    state = AppState(widget.supabaseReady);
    state.init();
  }

  @override
  Widget build(BuildContext context) {
    return AppStateScope(
      state: state,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Ptasia Mapa',
        theme: AppTheme.theme,
        navigatorKey: ptasiaNavigatorKey,
        routes: {
          '/reset-password': (_) => const PasswordResetPage(),
        },
        home: const HomePage(),
      ),
    );
  }
}

class AppTheme {
  static const green = Color(0xFF0A6B35);
  static const darkGreen = Color(0xFF064D2B);
  static const moss = Color(0xFF6B8E23);
  static const bark = Color(0xFF9A6427);
  static const cream = Color(0xFFFFFCF2);

  static ThemeData get theme {
    final scheme = ColorScheme.fromSeed(
      seedColor: green,
      brightness: Brightness.light,
      primary: green,
      secondary: moss,
      tertiary: bark,
      surface: cream,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: const Color(0xFFEFF7EA),
      appBarTheme: const AppBarTheme(
        backgroundColor: darkGreen,
        foregroundColor: Colors.white,
        centerTitle: false,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.1,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFDDEFD8),
        labelTextStyle: WidgetStateProperty.resolveWith(
          (states) => TextStyle(
            fontWeight: states.contains(WidgetState.selected) ? FontWeight.w900 : FontWeight.w600,
            fontSize: 12,
          ),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: green,
          foregroundColor: Colors.white,
          minimumSize: const Size.fromHeight(50),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: green,
          minimumSize: const Size.fromHeight(50),
          side: const BorderSide(color: Color(0xFFB7D6B4), width: 1.3),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFDDE8D4))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: green, width: 1.7)),
        filled: true,
        fillColor: Colors.white,
        labelStyle: const TextStyle(fontWeight: FontWeight.w700),
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: Colors.white,
        surfaceTintColor: Colors.white,
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: const BorderSide(color: Color(0xFFE1EADB)),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF26352A),
        contentTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}

class _ForestGradient extends StatelessWidget {
  const _ForestGradient();

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF064D2B), Color(0xFF0B7A3B), Color(0xFF5F8D2E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
    );
  }
}


class AppStateScope extends InheritedNotifier<AppState> {
  const AppStateScope({super.key, required AppState state, required super.child}) : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppStateScope>();
    if (scope == null || scope.notifier == null) {
      throw StateError('Brak AppStateScope');
    }
    return scope.notifier!;
  }
}

class AppState extends ChangeNotifier {
  AppState(this.supabaseReady);

  final bool supabaseReady;
  final List<NestSite> sites = [];
  final List<BirdObservation> birdObservations = [];
  final Set<String> sensitiveBirdSpecies = {
    'Puchacz',
    'Sóweczka',
    'Włochatka',
    'Orlik krzykliwy',
    'Orlik grubodzioby',
    'Bielik',
    'Rybołów',
    'Bocian czarny',
    'Głuszec',
    'Cietrzew',
  };
  final Map<String, Set<String>> sensitiveBirdAccessByEmail = {};
  final Uuid _uuid = const Uuid();

  int currentTab = 0;
  bool adminMode = false;
  bool pickingOnMap = false;
  String? errorMessage;
  String? infoMessage;
  bool syncing = false;
  bool checkingUpdate = false;
  bool updateDialogShown = false;
  UpdateInfo? availableUpdate;
  String? localGuestId;
  User? currentUser;
  String userRole = 'user';

  SupabaseClient? get client => supabaseReady ? Supabase.instance.client : null;
  bool get loggedIn => currentUser != null;
  bool get isSuperAdmin => (currentUser?.email ?? '').toLowerCase() == superAdminEmail.toLowerCase();
  bool get isAdminByProfile => userRole == 'admin' || userRole == 'super_admin';
  bool get isAdmin => adminMode || isAdminByProfile || isSuperAdmin;
  String get roleLabel {
    if (isSuperAdmin) return 'Super admin';
    if (isAdmin) return 'Administrator';
    if (loggedIn) return 'Użytkownik';
    return 'Gość';
  }

  Future<void> init() async {
    await _loadLocal();
    if (supabaseReady) {
      try {
        currentUser = client!.auth.currentUser;
        await _loadProfile();
        client!.auth.onAuthStateChange.listen((event) async {
          currentUser = event.session?.user;
          await _loadProfile();
          notifyListeners();

          if (event.event == AuthChangeEvent.passwordRecovery) {
            Future.microtask(() {
              ptasiaNavigatorKey.currentState?.pushNamed('/reset-password');
            });
          }
        });
      } catch (_) {
        currentUser = null;
      }
    }
    notifyListeners();
    Future.microtask(() => checkForUpdates(manual: false));
    if (supabaseReady && client != null) {
      Future.microtask(() async {
        await sync(silent: true);
        await syncBirdObservations(silent: true);
      });
    }
  }

  Future<void> _loadLocal() async {
    final prefs = await SharedPreferences.getInstance();
    localGuestId = prefs.getString('local_guest_id');
    if (localGuestId == null || localGuestId!.isEmpty) {
      localGuestId = 'guest-${_uuid.v4()}';
      await prefs.setString('local_guest_id', localGuestId!);
    }

    await _loadBirdObservationLocal(prefs);

    final raw = prefs.getString('sites_v1');
    if (raw == null || raw.isEmpty) return;

    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        sites
          ..clear()
          ..addAll(decoded.whereType<Map>().map((e) => NestSite.fromJson(Map<String, dynamic>.from(e))));
      }
    } catch (_) {
      await prefs.setString('sites_v1_broken_${DateTime.now().millisecondsSinceEpoch}', raw);
      await prefs.remove('sites_v1');
      sites.clear();
    }
  }

  Future<void> saveLocal() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(sites.map((e) => e.toJson()).toList());
    await prefs.setString('sites_v1', raw);
    await prefs.setString('bird_observations_v1', jsonEncode(birdObservations.map((e) => e.toJson()).toList()));
    await prefs.setString('sensitive_bird_species_v1', jsonEncode(sensitiveBirdSpecies.toList()));
    await prefs.setString(
      'sensitive_bird_access_v1',
      jsonEncode(sensitiveBirdAccessByEmail.map((key, value) => MapEntry(key, value.toList()))),
    );
  }

  Future<void> _loadProfile() async {
    userRole = 'user';
    if (!supabaseReady || currentUser == null) return;

    try {
      await client!.from('app_profiles').upsert({
        'user_id': currentUser!.id,
        'email': currentUser!.email ?? '',
        'role': isSuperAdmin ? 'super_admin' : 'user',
      }, onConflict: 'user_id');

      final row = await client!
          .from('app_profiles')
          .select('role')
          .eq('user_id', currentUser!.id)
          .maybeSingle();

      final role = row?['role']?.toString();
      if (role != null && role.isNotEmpty) userRole = role;
    } catch (_) {
      userRole = isSuperAdmin ? 'super_admin' : 'user';
    }
  }

  void setTab(int tab) {
    currentTab = tab;
    notifyListeners();
  }

  void setPicking(bool value) {
    pickingOnMap = value;
    notifyListeners();
  }

  void showError(String message) {
    errorMessage = message;
    infoMessage = null;
    notifyListeners();
  }

  void showInfo(String message) {
    infoMessage = message;
    errorMessage = null;
    notifyListeners();
  }

  void clearMessages() {
    errorMessage = null;
    infoMessage = null;
    notifyListeners();
  }

  List<NestSite> visibleSites() {
    final active = sites.where((s) => !s.deleted).toList();
    if (isAdmin) return active;

    // Gość i zwykły użytkownik widzą mapę oraz wszystkie nieukryte obiekty.
    // Edycja nadal jest ograniczona w canEdit(): admin albo właściciel obiektu.
    return active.where((s) => !s.hiddenFromUsers).toList();
  }

  List<NestSite> latestSites({int limit = 5}) {
    final list = visibleSites().toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list.take(limit).toList();
  }

  Map<String, int> commonBirds() {
    final map = <String, int>{};
    for (final s in visibleSites()) {
      for (final i in s.inspections) {
        if (i.birdsPresent && i.birdSpecies.trim().isNotEmpty) {
          map[i.birdSpecies] = (map[i.birdSpecies] ?? 0) + 1;
        }
      }
    }
    final entries = map.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Map.fromEntries(entries.take(8));
  }

  List<NestSite> repairSites() {
    final list = visibleSites().where(_siteNeedsRepair).toList();
    list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return list;
  }

  List<NestSite> cleanedSites() {
    final list = visibleSites().where((s) => _latestCleanedInspection(s) != null).toList();
    list.sort((a, b) {
      final ad = _latestCleanedInspection(a)?.date ?? DateTime(1900);
      final bd = _latestCleanedInspection(b)?.date ?? DateTime(1900);
      return bd.compareTo(ad);
    });
    return list;
  }

  List<NestSite> toCleanSites() {
    final now = DateTime.now();
    final list = visibleSites().where((s) => !_cleanedInSelectedSeason(s, now)).toList();
    list.sort((a, b) => a.name.compareTo(b.name));
    return list;
  }

  Future<LatLng> currentLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Lokalizacja w telefonie jest wyłączona.');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied) {
      throw Exception('Brak zgody na GPS. Nadaj zgodę w Androidzie.');
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception('GPS zablokowany na stałe. Wejdź w ustawienia aplikacji i nadaj zgodę.');
    }

    final pos = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
    );
    return LatLng(pos.latitude, pos.longitude);
  }

  Future<List<NearbySite>> findNearbySites({
    required double latitude,
    required double longitude,
    double radiusMeters = 35,
    String? excludeId,
  }) async {
    final center = LatLng(latitude, longitude);
    final distance = const Distance();
    final found = <String, NearbySite>{};

    void addCandidate(NestSite site) {
      if (site.deleted) return;
      if (excludeId != null && site.id == excludeId) return;

      final meters = distance.as(LengthUnit.Meter, center, LatLng(site.latitude, site.longitude));
      if (meters <= radiusMeters) {
        final old = found[site.id];
        final result = NearbySite(site: site, distanceMeters: meters);
        if (old == null || result.distanceMeters < old.distanceMeters) {
          found[site.id] = result;
        }
      }
    }

    for (final site in sites) {
      addCandidate(site);
    }

    if (supabaseReady && client != null) {
      try {
        final latDelta = radiusMeters / 111111.0;
        final lonDivider = 111111.0 * max(0.2, cos(latitude * pi / 180.0).abs());
        final lonDelta = radiusMeters / lonDivider;

        final rows = await client!
            .from('nest_sites')
            .select()
            .eq('deleted', false)
            .gte('latitude', latitude - latDelta)
            .lte('latitude', latitude + latDelta)
            .gte('longitude', longitude - lonDelta)
            .lte('longitude', longitude + lonDelta)
            .limit(25);

        for (final row in rows) {
          if (row is Map) {
            addCandidate(NestSite.fromServerMap(Map<String, dynamic>.from(row)));
          }
        }
      } catch (_) {
        // Brak internetu albo brak tabeli nie może blokować dodawania obiektu.
      }
    }

    final result = found.values.toList()
      ..sort((a, b) => a.distanceMeters.compareTo(b.distanceMeters));
    return result;
  }

  NestSite createSite({
    required String name,
    required String type,
    required double latitude,
    required double longitude,
    String placeDescription = '',
    String technicalStatus = 'Dobry',
    bool repairNeeded = false,
    String damageDescription = '',
    String notes = '',
    List<String> photoPaths = const [],
  }) {
    if (!canCreateObjects) {
      showInfo('Gość może tylko oglądać obiekty na mapie. Dodawanie wymaga zalogowania.');
      throw StateError('guest cannot create objects');
    }

    final now = DateTime.now();
    final site = NestSite(
      id: _uuid.v4(),
      name: name.trim().isEmpty ? 'Nowy obiekt' : name.trim(),
      type: type,
      latitude: latitude,
      longitude: longitude,
      placeDescription: placeDescription,
      technicalStatus: technicalStatus,
      repairNeeded: repairNeeded,
      damageDescription: damageDescription,
      notes: notes,
      photoPaths: List<String>.from(photoPaths),
      ownerId: currentUser?.id ?? localGuestId ?? 'guest',
      ownerEmail: currentUser?.email ?? 'gość',
      reportStatus: loggedIn ? 'Zgłoszona' : 'Zgłoszona anonimowo',
      createdAt: now,
      updatedAt: now,
      locallyChanged: true,
    );
    sites.add(site);
    saveLocal();
    notifyListeners();
    return site;
  }

  Future<void> updateSite(NestSite site) async {
    site.updatedAt = DateTime.now();
    site.locallyChanged = true;
    await saveLocal();
    notifyListeners();
  }

  bool canEdit(NestSite site) {
    if (isAdmin) return true;
    if (!loggedIn) return false;
    return site.ownerId == currentUser!.id;
  }

  bool get canCreateObjects => loggedIn || isAdmin;
  bool get canCreateBirdObservations => loggedIn || isAdmin;
  bool get canManageSensitiveBirds => isAdmin || isSuperAdmin;
  bool get canAddInspections => loggedIn || isAdmin;

  Future<void> deleteSite(NestSite site) async {
    site.deleted = true;
    site.updatedAt = DateTime.now();
    site.locallyChanged = true;
    await saveLocal();
    notifyListeners();
  }

  Future<void> requestDelete(NestSite site, String reason) async {
    site.deleteRequested = true;
    site.deleteReason = reason;
    site.updatedAt = DateTime.now();
    site.locallyChanged = true;
    await saveLocal();
    notifyListeners();
  }

  Future<void> _upsertNestSiteSafe(NestSite site) async {
    final data = site.toServerMap();

    try {
      await client!.from('nest_sites').upsert(data, onConflict: 'id');
    } catch (e) {
      final msg = e.toString();

      // Starsza baza mogła nie mieć jeszcze kolumny photo_urls. Wtedy zapisujemy obiekt bez zdjęć,
      // żeby synchronizacja całej aplikacji nie padała.
      if (msg.contains('photo_urls') || msg.contains('photo url') || msg.contains('PGRST204')) {
        final fallback = Map<String, dynamic>.from(data)..remove('photo_urls');
        await client!.from('nest_sites').upsert(fallback, onConflict: 'id');
        return;
      }

      rethrow;
    }
  }

  Future<void> _upsertInspectionSafe(NestSite site, Inspection inspection) async {
    try {
      await client!.from('inspections').upsert(inspection.toServerMap(site.id), onConflict: 'id');
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('inspections') || msg.contains('relation') || msg.contains('does not exist')) {
        throw Exception('Brakuje tabeli inspections. Uruchom w Supabase aktualny schema.sql.');
      }
      rethrow;
    }
  }

  Future<List<Inspection>> _loadInspectionsSafe(String siteId) async {
    try {
      final rows = await client!
          .from('inspections')
          .select()
          .eq('nest_site_id', siteId)
          .eq('deleted', false)
          .order('date', ascending: false);

      return rows.map<Inspection>((r) => Inspection.fromServerMap(Map<String, dynamic>.from(r))).toList();
    } catch (_) {
      // Brak tabeli inspekcji nie może ukrywać mapy i obiektów.
      return <Inspection>[];
    }
  }

  Future<void> sync({bool silent = false}) async {
    if (!supabaseReady || client == null) {
      if (!silent) showError('Supabase nie jest skonfigurowany. Sprawdź SUPABASE_URL i SUPABASE_ANON_KEY.');
      return;
    }

    if (syncing) return;
    syncing = true;
    if (!silent) clearMessages();
    notifyListeners();

    try {
      final localBeforeSync = {for (final s in sites) s.id: s};

      // 1. Wyślij lokalne zmiany. Robimy kopię listy, żeby nie modyfikować jej podczas pętli.
      final changedSites = sites.where((s) => s.locallyChanged).toList();
      for (final site in changedSites) {
        await _upsertNestSiteSafe(site);

        final changedInspections = site.inspections.where((i) => i.locallyChanged).toList();
        for (final inspection in changedInspections) {
          await _upsertInspectionSafe(site, inspection);
          inspection.locallyChanged = false;
        }

        site.locallyChanged = false;
      }

      // 2. Pobierz widoczne obiekty także dla gościa.
      // Wcześniej gość nie pobierał obiektów z Supabase, dlatego mapa mogła wyglądać jak pusta.
      dynamic query = client!.from('nest_sites').select();
      query = query.eq('deleted', false);

      if (!isAdmin) {
        query = query.eq('hidden_from_users', false);
      }

      final rows = await query.order('updated_at', ascending: false);

      final remoteSites = <NestSite>[];
      for (final row in rows) {
        final site = NestSite.fromServerMap(Map<String, dynamic>.from(row));

        final previousLocal = localBeforeSync[site.id];
        if (site.photoPaths.isEmpty && previousLocal != null && previousLocal.photoPaths.isNotEmpty) {
          site.photoPaths = previousLocal.photoPaths;
        }

        site.inspections = await _loadInspectionsSafe(site.id);

        // Jeżeli lokalnie mamy inspekcje, których jeszcze nie ma z serwera,
        // zachowujemy je zamiast nadpisać pustką.
        if (previousLocal != null && site.inspections.isEmpty && previousLocal.inspections.isNotEmpty) {
          site.inspections = previousLocal.inspections;
        }

        remoteSites.add(site);
      }

      // 3. Zachowaj lokalne niewysłane zmiany, jeśli coś nie zdążyło pójść na serwer.
      final stillLocalChanged = sites.where((s) => s.locallyChanged).toList();

      sites
        ..clear()
        ..addAll(remoteSites)
        ..addAll(stillLocalChanged.where((local) => remoteSites.every((remote) => remote.id != local.id)));

      await saveLocal();
      if (!silent) showInfo('Synchronizacja zakończona. Pobrano obiekty: ${remoteSites.length}.');
    } catch (e) {
      final msg = e.toString();
      if (!silent) {
        if (msg.contains('relation') || msg.contains('schema') || msg.contains('does not exist') || msg.contains('Could not find')) {
          showError('Błąd synchronizacji Supabase. Uruchom w Supabase aktualny plik supabase/schema.sql, potem spróbuj ponownie. Szczegóły: $e');
        } else if (msg.contains('JWT') || msg.contains('permission') || msg.contains('policy') || msg.contains('row-level security')) {
          showError('Błąd uprawnień Supabase/RLS. Sprawdź polityki w supabase/schema.sql. Szczegóły: $e');
        } else {
          showError('Błąd synchronizacji: $e');
        }
      }
    } finally {
      syncing = false;
      notifyListeners();
    }
  }

  void markUpdateDialogShown() {
    updateDialogShown = true;
  }

  Future<void> checkForUpdates({bool manual = false}) async {
    if (checkingUpdate) return;

    final hasJson = appUpdateJsonUrl.trim().isNotEmpty;
    final hasDirectApk = appUpdateApkUrl.trim().isNotEmpty;

    if (!hasJson) {
      if (manual && hasDirectApk) {
        showInfo('Brak adresu latest.json. Otwieram stronę pobierania.');
        await openUpdateDownload();
      } else if (manual) {
        showInfo('Brak adresu aktualizacji. Workflow powinien przekazać APP_UPDATE_JSON_URL do aplikacji.');
      }
      return;
    }

    checkingUpdate = true;
    if (manual) notifyListeners();

    try {
      final uri = Uri.parse(appUpdateJsonUrl.trim());
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode == 404) {
        if (manual) {
          if (hasDirectApk) {
            showInfo('Nie znaleziono latest.json. Otwieram stronę pobierania najnowszej wersji.');
            await openUpdateDownload();
          } else {
            showInfo('Nie znaleziono latest.json. Sprawdź, czy workflow utworzył Release i czy repo lub plik aktualizacji jest publicznie dostępny.');
          }
        }
        return;
      }
      if (res.statusCode < 200 || res.statusCode >= 300) {
        if (manual) showError('Nie udało się sprawdzić aktualizacji. Kod HTTP: ${res.statusCode}');
        return;
      }

      final data = jsonDecode(res.body);
      if (data is! Map) {
        if (manual) showError('Plik aktualizacji ma zły format.');
        return;
      }

      final info = UpdateInfo.fromJson(Map<String, dynamic>.from(data));
      if (info.versionCode > appVersionCode && info.apkUrl.isNotEmpty) {
        availableUpdate = info;
        updateDialogShown = false;
        showInfo('Dostępna jest nowa wersja programu: ${info.versionName}. Kliknij ikonę aktualizacji na górze albo przycisk Pobierz.');
      } else if (manual) {
        showInfo('Masz aktualną wersję programu: $appVersionName ($appVersionCode).');
      }
    } catch (e) {
      if (manual) showError('Błąd sprawdzania aktualizacji: $e');
    } finally {
      checkingUpdate = false;
      notifyListeners();
    }
  }

  Future<void> openUpdateDownload() async {
    final url = availableUpdate?.apkUrl.trim().isNotEmpty == true
        ? availableUpdate!.apkUrl.trim()
        : appUpdateApkUrl.trim();

    if (url.isEmpty) {
      showError('Brak linku do APK.');
      return;
    }

    final uri = Uri.parse(url);
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok) {
      showError('Nie udało się otworzyć linku aktualizacji.');
    }
  }

  Future<void> signIn(String email, String password) async {
    if (!supabaseReady || client == null) {
      showError('Brak konfiguracji Supabase.');
      return;
    }

    final cleanEmail = email.trim();
    if (cleanEmail.isEmpty || password.trim().isEmpty) {
      showError('Wpisz email i hasło.');
      return;
    }

    try {
      final res = await client!.auth.signInWithPassword(
        email: cleanEmail,
        password: password.trim(),
      );
      currentUser = res.user;
      await _loadProfile();
      showInfo('Zalogowano.');
      notifyListeners();
      await sync();
    } catch (e) {
      showError('Błąd logowania: ${_friendlyAuthError(e)}');
    }
  }

  Future<void> register(String email, String password) async {
    if (!supabaseReady || client == null) {
      showError('Brak konfiguracji Supabase.');
      return;
    }

    final cleanEmail = email.trim();
    final cleanPassword = password.trim();

    if (cleanEmail.isEmpty) {
      showError('Wpisz email.');
      return;
    }
    if (cleanPassword.length < 6) {
      showError('Hasło powinno mieć minimum 6 znaków.');
      return;
    }

    try {
      final res = await client!.auth.signUp(
        email: cleanEmail,
        password: cleanPassword,
        emailRedirectTo: oauthRedirectTo,
      );
      currentUser = res.user ?? client!.auth.currentUser;

      // Gdy w Supabase wyłączysz Confirm email, konto jest aktywne od razu.
      // Dodatkowo próbujemy od razu zalogować użytkownika, żeby nie musiał nic potwierdzać.
      if (client!.auth.currentSession == null) {
        try {
          final login = await client!.auth.signInWithPassword(
            email: cleanEmail,
            password: cleanPassword,
          );
          currentUser = login.user ?? currentUser;
        } catch (_) {
          // Jeśli Supabase nadal wymaga potwierdzenia emaila, nie wywracamy aplikacji.
        }
      }

      await _loadProfile();
      showInfo('Konto utworzone. Jeżeli Supabase wymaga potwierdzenia, sprawdź email.');
      notifyListeners();

      try {
        await sync();
      } catch (_) {
        // Konto zostało utworzone poprawnie. Błąd synchronizacji nie może być pokazany jako błąd rejestracji.
      }
    } catch (e) {
      showError('Błąd rejestracji: ${_friendlyAuthError(e)}');
    }
  }

  Future<void> sendPasswordReset(String email) async {
    if (!supabaseReady || client == null) {
      showError('Brak konfiguracji Supabase.');
      return;
    }

    final cleanEmail = email.trim();
    if (cleanEmail.isEmpty) {
      showError('Najpierw wpisz email, potem kliknij reset hasła.');
      return;
    }

    try {
      await client!.auth.resetPasswordForEmail(
        cleanEmail,
        redirectTo: passwordResetRedirectTo,
      );
      showInfo('Wysłano link do resetu hasła na podany email.');
    } catch (e) {
      showError('Błąd resetu hasła: ${_friendlyAuthError(e)}');
    }
  }

  Future<void> signInWithGoogle() async {
    if (!supabaseReady || client == null) {
      showError('Brak konfiguracji Supabase.');
      return;
    }
    try {
      await client!.auth.signInWithOAuth(
        OAuthProvider.google,
        redirectTo: oauthRedirectTo,
      );
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('provider is not enabled') || msg.contains('Unsupported provider')) {
        showError('Logowanie Google nie jest włączone w Supabase. Włącz Authentication → Providers → Google albo użyj logowania email/hasło.');
      } else {
        showError('Błąd Google OAuth: ${_friendlyAuthError(e)}');
      }
    }
  }

  String _friendlyAuthError(Object error) {
    final raw = error.toString();
    final msg = raw.toLowerCase();

    if (msg.contains('invalid login credentials')) {
      return 'nieprawidłowy email albo hasło.';
    }
    if (msg.contains('email not confirmed')) {
      return 'email nie został jeszcze potwierdzony.';
    }
    if (msg.contains('already registered') || msg.contains('user already exists')) {
      return 'konto z tym adresem email już istnieje.';
    }
    if (msg.contains('signup disabled')) {
      return 'rejestracja jest wyłączona w Supabase.';
    }
    if (msg.contains('provider is not enabled') || msg.contains('unsupported provider')) {
      return 'logowanie Google nie jest włączone w Supabase.';
    }
    if (msg.contains('socket') || msg.contains('network') || msg.contains('failed host lookup')) {
      return 'brak połączenia z internetem.';
    }

    return raw;
  }

  Future<void> signOut() async {
    try {
      await client?.auth.signOut();
    } catch (_) {}
    currentUser = null;
    userRole = 'user';
    adminMode = false;
    await _loadLocal();
    notifyListeners();
  }

  Future<void> enableAdminWithPassword(String password) async {
    if (password == adminPassword) {
      adminMode = true;
      currentTab = 0;
      showInfo('Tryb administratora włączony.');
    } else {
      showError('Nieprawidłowe hasło administratora.');
    }
  }

  Future<void> disableAdmin() async {
    adminMode = false;
    if (currentTab > 1) currentTab = 0;
    notifyListeners();
  }

  Future<void> grantAdmin(String email) async {
    if (!isSuperAdmin) {
      showError('Tylko super administrator może nadawać uprawnienia.');
      return;
    }
    if (!supabaseReady || client == null) {
      showError('Brak Supabase.');
      return;
    }
    try {
      await client!.from('app_profiles').upsert({
        'email': email.trim(),
        'role': 'admin',
      }, onConflict: 'email');
      showInfo('Nadano uprawnienia admin dla $email');
    } catch (e) {
      showError('Błąd nadawania uprawnień: $e');
    }
  }


  Future<void> _loadBirdObservationLocal(SharedPreferences prefs) async {
    final rawObs = prefs.getString('bird_observations_v1');
    if (rawObs != null && rawObs.isNotEmpty) {
      try {
        final decoded = jsonDecode(rawObs);
        if (decoded is List) {
          birdObservations
            ..clear()
            ..addAll(decoded.whereType<Map>().map((e) => BirdObservation.fromJson(Map<String, dynamic>.from(e))));
        }
      } catch (_) {
        await prefs.setString('bird_observations_v1_broken_${DateTime.now().millisecondsSinceEpoch}', rawObs);
        await prefs.remove('bird_observations_v1');
        birdObservations.clear();
      }
    }

    final rawSensitive = prefs.getString('sensitive_bird_species_v1');
    if (rawSensitive != null && rawSensitive.isNotEmpty) {
      try {
        final decoded = jsonDecode(rawSensitive);
        if (decoded is List) {
          sensitiveBirdSpecies
            ..clear()
            ..addAll(decoded.map((e) => e.toString()).where((e) => e.trim().isNotEmpty));
        }
      } catch (_) {}
    }

    final rawAccess = prefs.getString('sensitive_bird_access_v1');
    if (rawAccess != null && rawAccess.isNotEmpty) {
      try {
        final decoded = jsonDecode(rawAccess);
        if (decoded is Map) {
          sensitiveBirdAccessByEmail
            ..clear()
            ..addEntries(decoded.entries.map((entry) {
              final list = entry.value is List ? entry.value as List : const [];
              return MapEntry(entry.key.toString().toLowerCase(), list.map((e) => e.toString()).toSet());
            }));
        }
      } catch (_) {}
    }
  }

  bool isBirdSpeciesSensitive(String species) {
    final name = _normBird(species);
    return sensitiveBirdSpecies.map(_normBird).contains(name);
  }

  bool canSeeExactBirdLocation(BirdObservation observation) {
    if (!observation.isSensitive && !isBirdSpeciesSensitive(observation.speciesName)) return true;
    if (isAdmin || isSuperAdmin) return true;
    final email = (currentUser?.email ?? '').trim().toLowerCase();
    if (email.isEmpty) return false;
    final allowed = sensitiveBirdAccessByEmail[email] ?? const <String>{};
    return allowed.map(_normBird).contains('*') || allowed.map(_normBird).contains(_normBird(observation.speciesName));
  }

  LatLng visibleBirdPoint(BirdObservation observation) {
    if (canSeeExactBirdLocation(observation)) {
      return LatLng(observation.latitude, observation.longitude);
    }
    return _blurBirdPoint(
      observation.latitude,
      observation.longitude,
      seed: '${observation.speciesName}|${observation.locationName}|${observation.id}',
    );
  }

  List<BirdObservation> visibleBirdObservations() {
    final list = birdObservations.toList();
    list.sort((a, b) => b.observedAt.compareTo(a.observedAt));
    return list;
  }

  Future<void> addBirdObservation(BirdObservation observation) async {
    if (!canCreateBirdObservations) {
      showInfo('Gość może oglądać obserwacje. Dodawanie wymaga zalogowania.');
      throw StateError('guest cannot create bird observations');
    }

    birdObservations.removeWhere((o) => o.id == observation.id);
    birdObservations.insert(0, observation);
    await saveLocal();
    notifyListeners();

    if (supabaseReady && client != null) {
      await _upsertBirdObservationSafe(observation);
    }
  }

  Future<void> confirmBirdObservation(BirdObservation observation, {required bool? stillPresent, required String comment}) async {
    final confirmation = BirdObservationConfirmation(
      id: _uuid.v4(),
      observationId: observation.id,
      userEmail: currentUser?.email ?? '',
      displayName: currentUser?.email ?? 'Użytkownik',
      seenAt: DateTime.now(),
      stillPresent: stillPresent,
      comment: comment.trim(),
    );

    observation.confirmations.insert(0, confirmation);
    observation.status = stillPresent == true
        ? BirdObservationStatus.active
        : stillPresent == false
            ? BirdObservationStatus.notSeen
            : BirdObservationStatus.unknown;
    observation.updatedAt = DateTime.now();

    await saveLocal();
    notifyListeners();

    if (supabaseReady && client != null) {
      try {
        await client!.from('bird_observation_confirmations').upsert(confirmation.toServerMap(), onConflict: 'id');
        await client!.from('bird_observations').update({
          'status': observation.status.serverValue,
          'updated_at': observation.updatedAt.toIso8601String(),
        }).eq('id', observation.id);
      } catch (e) {
        showError('Potwierdzenie zapisane lokalnie, ale nie wysłane do Supabase: $e');
      }
    }
  }

  Future<int> importBirdObservationsFromClanga() async {
    try {
      final imported = await ClangaBirdImporter().fetchRecent();
      var added = 0;
      final existing = birdObservations.map((o) => o.dedupeKey).toSet();
      for (final obs in imported) {
        obs.isSensitive = obs.isSensitive || isBirdSpeciesSensitive(obs.speciesName);
        if (existing.contains(obs.dedupeKey)) continue;
        birdObservations.insert(0, obs);
        existing.add(obs.dedupeKey);
        added++;
      }
      await saveLocal();
      notifyListeners();

      if (supabaseReady && client != null) {
        for (final obs in imported.take(added)) {
          await _upsertBirdObservationSafe(obs);
        }
      }

      showInfo('Import z Clanga zakończony. Nowe obserwacje: $added.');
      return added;
    } catch (e) {
      showError('Nie udało się pobrać obserwacji z Clanga: $e');
      rethrow;
    }
  }

  Future<void> _upsertBirdObservationSafe(BirdObservation observation) async {
    if (!supabaseReady || client == null) return;

    final publicPoint = observation.isSensitive || isBirdSpeciesSensitive(observation.speciesName)
        ? _blurBirdPoint(
            observation.latitude,
            observation.longitude,
            seed: '${observation.speciesName}|${observation.locationName}|${observation.id}',
          )
        : LatLng(observation.latitude, observation.longitude);

    final data = observation.toPublicServerMap(
      ownerId: currentUser?.id ?? '',
      ownerEmail: currentUser?.email ?? '',
      publicLatitude: publicPoint.latitude,
      publicLongitude: publicPoint.longitude,
      sensitive: observation.isSensitive || isBirdSpeciesSensitive(observation.speciesName),
    );

    try {
      await client!.from('bird_observations').upsert(data, onConflict: 'id');
      await client!.from('bird_observation_exact_locations').upsert({
        'observation_id': observation.id,
        'species_name': observation.speciesName,
        'latitude': observation.latitude,
        'longitude': observation.longitude,
        'updated_at': DateTime.now().toIso8601String(),
      }, onConflict: 'observation_id');
    } catch (e) {
      showError('Obserwacja zapisana lokalnie, ale nie wysłana do Supabase: $e');
    }
  }

  Future<void> syncBirdObservations({bool silent = false}) async {
    if (!supabaseReady || client == null) return;

    try {
      final localById = {for (final o in birdObservations) o.id: o};

      for (final obs in birdObservations.where((o) => o.locallyChanged).toList()) {
        await _upsertBirdObservationSafe(obs);
        obs.locallyChanged = false;
      }

      final sensitiveRows = await client!.from('bird_sensitive_species').select();
      sensitiveBirdSpecies
        ..clear()
        ..addAll((sensitiveRows as List).map((row) => (row as Map)['species_name'].toString()));

      final accessRows = await client!.from('bird_sensitive_access').select();
      sensitiveBirdAccessByEmail.clear();
      for (final row in accessRows as List) {
        final map = Map<String, dynamic>.from(row as Map);
        final email = (map['email'] ?? '').toString().toLowerCase();
        final species = (map['species_name'] ?? '').toString();
        if (email.isEmpty || species.isEmpty) continue;
        sensitiveBirdAccessByEmail.putIfAbsent(email, () => <String>{}).add(species);
      }

      final rows = await client!.from('bird_observations').select().order('observed_at', ascending: false).limit(500);
      final exactRows = await client!.from('bird_observation_exact_locations').select();
      final exactById = <String, Map<String, dynamic>>{};
      for (final row in exactRows as List) {
        final map = Map<String, dynamic>.from(row as Map);
        exactById[(map['observation_id'] ?? '').toString()] = map;
      }

      final remote = <BirdObservation>[];
      for (final row in rows as List) {
        final obs = BirdObservation.fromPublicServerMap(Map<String, dynamic>.from(row as Map));
        final exact = exactById[obs.id];
        if (exact != null) {
          obs.latitude = _doubleValue(exact['latitude']) ?? obs.latitude;
          obs.longitude = _doubleValue(exact['longitude']) ?? obs.longitude;
          obs.locationAccuracy = 'dokładna';
        }

        final previous = localById[obs.id];
        if (previous != null) {
          obs.photoPaths = previous.photoPaths;
          obs.confirmations = previous.confirmations;
        }
        remote.add(obs);
      }

      final localChanged = birdObservations.where((o) => o.locallyChanged && remote.every((r) => r.id != o.id));
      birdObservations
        ..clear()
        ..addAll(remote)
        ..addAll(localChanged);

      await saveLocal();
      if (!silent) showInfo('Synchronizacja obserwacji zakończona. Pobrano: ${remote.length}.');
      notifyListeners();
    } catch (e) {
      if (!silent) showError('Nie udało się zsynchronizować obserwacji ptaków: $e');
    }
  }

  Future<void> setSensitiveBirdSpecies(String speciesName, bool sensitive) async {
    final clean = speciesName.trim();
    if (clean.isEmpty) return;
    if (sensitive) {
      sensitiveBirdSpecies.add(clean);
    } else {
      sensitiveBirdSpecies.removeWhere((s) => _normBird(s) == _normBird(clean));
      for (final set in sensitiveBirdAccessByEmail.values) {
        set.removeWhere((s) => _normBird(s) == _normBird(clean));
      }
    }

    for (final obs in birdObservations.where((o) => _normBird(o.speciesName) == _normBird(clean))) {
      obs.isSensitive = sensitive;
      obs.locallyChanged = true;
    }

    await saveLocal();
    notifyListeners();

    if (supabaseReady && client != null) {
      try {
        if (sensitive) {
          await client!.from('bird_sensitive_species').upsert({'species_name': clean}, onConflict: 'species_name');
        } else {
          await client!.from('bird_sensitive_species').delete().eq('species_name', clean);
        }
      } catch (e) {
        showError('Nie udało się zapisać gatunku wrażliwego w Supabase: $e');
      }
    }
  }

  Future<void> setSensitiveBirdAccess({required String email, required String speciesName, required bool allowed}) async {
    final cleanEmail = email.trim().toLowerCase();
    final cleanSpecies = speciesName.trim();
    if (cleanEmail.isEmpty || cleanSpecies.isEmpty) return;

    final set = sensitiveBirdAccessByEmail.putIfAbsent(cleanEmail, () => <String>{});
    if (allowed) {
      set.add(cleanSpecies);
    } else {
      set.removeWhere((s) => _normBird(s) == _normBird(cleanSpecies));
    }

    await saveLocal();
    notifyListeners();

    if (supabaseReady && client != null) {
      try {
        if (allowed) {
          await client!.from('bird_sensitive_access').upsert({
            'email': cleanEmail,
            'species_name': cleanSpecies,
          }, onConflict: 'email,species_name');
        } else {
          await client!.from('bird_sensitive_access').delete().eq('email', cleanEmail).eq('species_name', cleanSpecies);
        }
      } catch (e) {
        showError('Nie udało się zapisać dostępu w Supabase: $e');
      }
    }
  }

  String exportBirdObservationsCsv() {
    final rows = <List<String>>[
      ['id', 'gatunek', 'liczba', 'miejsce', 'lat_widoczne', 'lng_widoczne', 'data', 'status', 'zrodlo', 'wrazliwy']
    ];
    for (final o in visibleBirdObservations()) {
      final p = visibleBirdPoint(o);
      rows.add([
        o.id,
        o.speciesName,
        o.count.toString(),
        o.locationName,
        p.latitude.toString(),
        p.longitude.toString(),
        o.observedAt.toIso8601String(),
        o.status.label,
        o.source.label,
        (o.isSensitive || isBirdSpeciesSensitive(o.speciesName)).toString(),
      ]);
    }
    return rows.map((r) => r.map(_csvCell).join(',')).join('\n');
  }

  String exportBirdObservationsKml() {
    final b = StringBuffer();
    b.writeln('<?xml version="1.0" encoding="UTF-8"?>');
    b.writeln('<kml xmlns="http://www.opengis.net/kml/2.2"><Document>');
    b.writeln('<name>Ptasia Mapa - obserwacje ptaków</name>');
    for (final o in visibleBirdObservations()) {
      final p = visibleBirdPoint(o);
      b.writeln('<Placemark>');
      b.writeln('<name>${_xml('${o.speciesName} — ${o.locationName}')}</name>');
      b.writeln('<description>${_xml('${o.count} os. | ${o.status.label} | ${o.source.label} | ${DateFormat('dd.MM.yyyy HH:mm').format(o.observedAt)}')}</description>');
      b.writeln('<Point><coordinates>${p.longitude},${p.latitude},0</coordinates></Point>');
      b.writeln('</Placemark>');
    }
    b.writeln('</Document></kml>');
    return b.toString();
  }

  String exportCsv() {
    final rows = <List<String>>[
      ['id', 'nazwa', 'typ', 'lat', 'lng', 'status', 'ptaki', 'wlasciciel', 'utworzono']
    ];
    for (final s in visibleSites()) {
      rows.add([
        s.id,
        s.name,
        s.type,
        s.latitude.toString(),
        s.longitude.toString(),
        s.technicalStatus,
        s.inspections.where((i) => i.birdsPresent).map((i) => i.birdSpecies).join('; '),
        s.ownerEmail,
        s.createdAt.toIso8601String(),
      ]);
    }
    return rows.map((r) => r.map(_csvCell).join(',')).join('\n');
  }

  String exportKml() {
    final b = StringBuffer();
    b.writeln('<?xml version="1.0" encoding="UTF-8"?>');
    b.writeln('<kml xmlns="http://www.opengis.net/kml/2.2"><Document>');
    for (final s in visibleSites()) {
      b.writeln('<Placemark><name>${_xml(s.name)}</name><description>${_xml(s.type)}</description><Point><coordinates>${s.longitude},${s.latitude},0</coordinates></Point></Placemark>');
    }
    b.writeln('</Document></kml>');
    return b.toString();
  }

  String exportGpx() {
    final b = StringBuffer();
    b.writeln('<?xml version="1.0" encoding="UTF-8"?>');
    b.writeln('<gpx version="1.1" creator="Ptasia Mapa">');
    for (final s in visibleSites()) {
      b.writeln('<wpt lat="${s.latitude}" lon="${s.longitude}"><name>${_xml(s.name)}</name><desc>${_xml(s.type)}</desc></wpt>');
    }
    b.writeln('</gpx>');
    return b.toString();
  }

  Future<void> importSimpleGpxKml(String text) async {
    final pointRegex = RegExp(r'lat="([0-9\.\-]+)"\s+lon="([0-9\.\-]+)"|<coordinates>\s*([0-9\.\-]+),([0-9\.\-]+),?0?\s*</coordinates>');
    int count = 0;
    for (final m in pointRegex.allMatches(text)) {
      double? lat;
      double? lng;
      if (m.group(1) != null && m.group(2) != null) {
        lat = double.tryParse(m.group(1)!);
        lng = double.tryParse(m.group(2)!);
      } else if (m.group(3) != null && m.group(4) != null) {
        lng = double.tryParse(m.group(3)!);
        lat = double.tryParse(m.group(4)!);
      }
      if (lat != null && lng != null) {
        createSite(name: 'Import $count', type: 'Inne', latitude: lat, longitude: lng);
        count++;
      }
    }
    showInfo('Zaimportowano punktów: $count');
  }
}

String _csvCell(String value) => '"${value.replaceAll('"', '""')}"';
String _xml(String value) => value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');


enum BirdObservationSource {
  user,
  clanga,
}

extension BirdObservationSourceLabel on BirdObservationSource {
  String get label => this == BirdObservationSource.clanga ? 'Clanga' : 'Własne';
  String get serverValue => this == BirdObservationSource.clanga ? 'clanga' : 'user';
}

enum BirdObservationStatus {
  active,
  notSeen,
  unknown,
}


BirdObservationSource _birdSourceFromServer(String? value) {
  return value == 'clanga' ? BirdObservationSource.clanga : BirdObservationSource.user;
}

BirdObservationStatus _birdStatusFromServer(String? value) {
  switch (value) {
    case 'active':
      return BirdObservationStatus.active;
    case 'not_seen':
      return BirdObservationStatus.notSeen;
    default:
      return BirdObservationStatus.unknown;
  }
}

extension BirdObservationStatusLabel on BirdObservationStatus {
  String get label {
    switch (this) {
      case BirdObservationStatus.active:
        return 'nadal obserwowany';
      case BirdObservationStatus.notSeen:
        return 'nie ma / niepotwierdzony';
      case BirdObservationStatus.unknown:
        return 'nie wiadomo';
    }
  }

  String get serverValue {
    switch (this) {
      case BirdObservationStatus.active:
        return 'active';
      case BirdObservationStatus.notSeen:
        return 'not_seen';
      case BirdObservationStatus.unknown:
        return 'unknown';
    }
  }
}

class BirdObservationConfirmation {
  BirdObservationConfirmation({
    required this.id,
    required this.observationId,
    this.userEmail = '',
    this.displayName = '',
    required this.seenAt,
    this.stillPresent,
    this.comment = '',
  });

  String id;
  String observationId;
  String userEmail;
  String displayName;
  DateTime seenAt;
  bool? stillPresent;
  String comment;

  Map<String, dynamic> toJson() => {
        'id': id,
        'observationId': observationId,
        'userEmail': userEmail,
        'displayName': displayName,
        'seenAt': seenAt.toIso8601String(),
        'stillPresent': stillPresent,
        'comment': comment,
      };

  factory BirdObservationConfirmation.fromJson(Map<String, dynamic> j) {
    return BirdObservationConfirmation(
      id: j['id']?.toString() ?? const Uuid().v4(),
      observationId: j['observationId']?.toString() ?? j['observation_id']?.toString() ?? '',
      userEmail: j['userEmail']?.toString() ?? j['user_email']?.toString() ?? '',
      displayName: j['displayName']?.toString() ?? j['display_name']?.toString() ?? '',
      seenAt: _date(j['seenAt'] ?? j['seen_at']),
      stillPresent: j['stillPresent'] is bool ? j['stillPresent'] as bool : j['still_present'] as bool?,
      comment: j['comment']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toServerMap() => {
        'id': id,
        'observation_id': observationId,
        'user_email': userEmail,
        'display_name': displayName,
        'seen_at': seenAt.toIso8601String(),
        'still_present': stillPresent,
        'comment': comment,
      };
}

class BirdObservation {
  BirdObservation({
    required this.id,
    required this.speciesName,
    this.speciesNameEn = '',
    this.latinName = '',
    this.birdGroup = '',
    this.count = 1,
    required this.locationName,
    required this.latitude,
    required this.longitude,
    required this.observedAt,
    this.source = BirdObservationSource.user,
    this.sourceUrl = '',
    this.observerName = '',
    this.status = BirdObservationStatus.unknown,
    this.isSensitive = false,
    this.locationResolved = true,
    this.locationAccuracy = 'GPS',
    this.ownerId = '',
    this.ownerEmail = '',
    this.locallyChanged = true,
    this.photoPaths = const [],
    List<BirdObservationConfirmation>? confirmations,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : confirmations = confirmations ?? [],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  String id;
  String speciesName;
  String speciesNameEn;
  String latinName;
  String birdGroup;
  int count;
  String locationName;
  double latitude;
  double longitude;
  DateTime observedAt;
  BirdObservationSource source;
  String sourceUrl;
  String observerName;
  BirdObservationStatus status;
  bool isSensitive;
  bool locationResolved;
  String locationAccuracy;
  String ownerId;
  String ownerEmail;
  bool locallyChanged;
  List<String> photoPaths;
  List<BirdObservationConfirmation> confirmations;
  DateTime createdAt;
  DateTime updatedAt;

  String get dedupeKey => '${_normBird(speciesName)}|${locationName.trim().toLowerCase()}|${DateFormat('yyyy-MM-dd').format(observedAt)}|${source.serverValue}';

  Map<String, dynamic> toJson() => {
        'id': id,
        'speciesName': speciesName,
        'speciesNameEn': speciesNameEn,
        'latinName': latinName,
        'birdGroup': birdGroup,
        'count': count,
        'locationName': locationName,
        'latitude': latitude,
        'longitude': longitude,
        'observedAt': observedAt.toIso8601String(),
        'source': source.serverValue,
        'sourceUrl': sourceUrl,
        'observerName': observerName,
        'status': status.serverValue,
        'isSensitive': isSensitive,
        'locationResolved': locationResolved,
        'locationAccuracy': locationAccuracy,
        'ownerId': ownerId,
        'ownerEmail': ownerEmail,
        'locallyChanged': locallyChanged,
        'photoPaths': photoPaths,
        'confirmations': confirmations.map((e) => e.toJson()).toList(),
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory BirdObservation.fromJson(Map<String, dynamic> j) {
    final confirmationsRaw = j['confirmations'];
    final confirmations = confirmationsRaw is List
        ? confirmationsRaw.whereType<Map>().map((e) => BirdObservationConfirmation.fromJson(Map<String, dynamic>.from(e))).toList()
        : <BirdObservationConfirmation>[];
    return BirdObservation(
      id: j['id']?.toString() ?? const Uuid().v4(),
      speciesName: j['speciesName']?.toString() ?? j['species_name']?.toString() ?? 'Nieznany gatunek',
      speciesNameEn: j['speciesNameEn']?.toString() ?? j['species_name_en']?.toString() ?? '',
      latinName: j['latinName']?.toString() ?? j['latin_name']?.toString() ?? '',
      birdGroup: j['birdGroup']?.toString() ?? j['bird_group']?.toString() ?? '',
      count: _intValue(j['count']) ?? 1,
      locationName: j['locationName']?.toString() ?? j['location_name']?.toString() ?? '',
      latitude: _doubleValue(j['latitude']) ?? _doubleValue(j['lat_public']) ?? 52.1,
      longitude: _doubleValue(j['longitude']) ?? _doubleValue(j['lng_public']) ?? 19.4,
      observedAt: _date(j['observedAt'] ?? j['observed_at']),
      source: _birdSourceFromServer(j['source']?.toString()),
      sourceUrl: j['sourceUrl']?.toString() ?? j['source_url']?.toString() ?? '',
      observerName: j['observerName']?.toString() ?? j['observer_name']?.toString() ?? '',
      status: _birdStatusFromServer(j['status']?.toString()),
      isSensitive: j['isSensitive'] == true || j['is_sensitive'] == true,
      locationResolved: j['locationResolved'] != false && j['location_resolved'] != false,
      locationAccuracy: j['locationAccuracy']?.toString() ?? j['location_accuracy']?.toString() ?? 'przybliżona',
      ownerId: j['ownerId']?.toString() ?? j['owner_id']?.toString() ?? '',
      ownerEmail: j['ownerEmail']?.toString() ?? j['owner_email']?.toString() ?? '',
      locallyChanged: j['locallyChanged'] == true,
      photoPaths: (j['photoPaths'] is List)
          ? (j['photoPaths'] as List).map((e) => e.toString()).toList()
          : (j['photo_urls'] is List)
              ? (j['photo_urls'] as List).map((e) => e.toString()).toList()
              : const [],
      confirmations: confirmations,
      createdAt: _date(j['createdAt'] ?? j['created_at']),
      updatedAt: _date(j['updatedAt'] ?? j['updated_at']),
    );
  }

  factory BirdObservation.fromPublicServerMap(Map<String, dynamic> j) {
    return BirdObservation.fromJson({
      ...j,
      'latitude': j['lat_public'],
      'longitude': j['lng_public'],
      'locallyChanged': false,
    });
  }

  Map<String, dynamic> toPublicServerMap({
    required String ownerId,
    required String ownerEmail,
    required double publicLatitude,
    required double publicLongitude,
    required bool sensitive,
  }) => {
        'id': id,
        'species_name': speciesName,
        'species_name_en': speciesNameEn,
        'latin_name': latinName,
        'bird_group': birdGroup,
        'count': count,
        'location_name': locationName,
        'lat_public': publicLatitude,
        'lng_public': publicLongitude,
        'observed_at': observedAt.toIso8601String(),
        'source': source.serverValue,
        'source_url': sourceUrl,
        'observer_name': observerName,
        'status': status.serverValue,
        'is_sensitive': sensitive,
        'location_resolved': locationResolved,
        'location_accuracy': sensitive ? 'przybliżona dla zwykłych użytkowników' : locationAccuracy,
        'owner_id': ownerId,
        'owner_email': ownerEmail,
        'photo_urls': photoPaths,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };
}

class ClangaBirdImporter {
  static const url = 'https://www.clanga.com/index.php/news/show';

  Future<List<BirdObservation>> fetchRecent() async {
    final response = await http
        .get(Uri.parse(url), headers: const {'User-Agent': 'PtasiaMapa/0.6.1 bird observations importer'})
        .timeout(const Duration(seconds: 20));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Clanga HTTP ${response.statusCode}');
    }
    return parse(response.body);
  }

  List<BirdObservation> parse(String html) {
    final doc = html_parser.parse(html);
    final text = (doc.body?.text ?? '')
        .replaceAll('\r', '\n')
        .replaceAll(RegExp(r'\n+'), '\n')
        .replaceAll(RegExp(r'[ \t]+'), ' ');

    final records = <BirdObservation>[];
    final regex = RegExp(
      r'([A-Z][A-Za-z’ʼ\-\s]+?),\s*([A-Z][a-z]+(?:\s+[a-z]+){1,2})\s+([0-9]+)\s+ind\.\s+(.+?)\s+obs\./info:\s*(.+?)(?=(?:[A-Z][A-Za-z’ʼ\-\s]+?,\s*[A-Z][a-z]+(?:\s+[a-z]+){1,2}\s+[0-9]+\s+ind\.)|$)',
      dotAll: true,
    );

    for (final match in regex.allMatches(text)) {
      final speciesEn = _cleanClanga(match.group(1) ?? '');
      final latin = _cleanClanga(match.group(2) ?? '');
      final count = int.tryParse(match.group(3) ?? '1') ?? 1;
      final location = _cleanClanga(match.group(4) ?? '').replaceAll(RegExp(r'Photographed\.?', caseSensitive: false), '').trim();
      final observer = _cleanClanga(match.group(5) ?? '');
      final resolved = BirdLocationResolver.resolve(location);
      final speciesPl = BirdSpeciesNames.toPolish(speciesEn, latin);

      records.add(BirdObservation(
        id: const Uuid().v4(),
        speciesName: speciesPl,
        speciesNameEn: speciesEn,
        latinName: latin,
        birdGroup: BirdSpeciesNames.group(speciesPl, speciesEn),
        count: count,
        locationName: location,
        latitude: resolved.point.latitude,
        longitude: resolved.point.longitude,
        observedAt: DateTime.now(),
        source: BirdObservationSource.clanga,
        sourceUrl: url,
        observerName: observer,
        status: BirdObservationStatus.unknown,
        isSensitive: BirdSpeciesNames.defaultSensitive(speciesPl, latin),
        locationResolved: resolved.resolved,
        locationAccuracy: resolved.resolved ? 'z nazwy miejsca' : 'do ustawienia ręcznie',
      ));
    }
    return records;
  }

  static String _cleanClanga(String value) => value.replaceAll('\n', ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
}

class BirdResolvedLocation {
  const BirdResolvedLocation(this.point, this.resolved);
  final LatLng point;
  final bool resolved;
}

class BirdLocationResolver {
  static BirdResolvedLocation resolve(String locationName) {
    final text = locationName.toLowerCase();
    final known = <String, LatLng>{
      'mikoszew': const LatLng(54.3487, 18.9544),
      'ujście wisły': const LatLng(54.3487, 18.9544),
      'stegna': const LatLng(54.3266, 19.1125),
      'tczew': const LatLng(54.0924, 18.7779),
      'beka': const LatLng(54.6618, 18.4975),
      'zatoka pucka': const LatLng(54.6880, 18.5160),
      'spytkowice': const LatLng(49.9963, 19.5112),
      'okołowice': const LatLng(50.8630, 19.2780),
      'dolina baryczy': const LatLng(51.5350, 17.3150),
      'hel': const LatLng(54.6081, 18.8014),
      'krynica morska': const LatLng(54.3805, 19.4445),
      'gdańsk': const LatLng(54.3520, 18.6466),
      'gdynia': const LatLng(54.5189, 18.5305),
    };
    for (final entry in known.entries) {
      if (text.contains(entry.key)) return BirdResolvedLocation(entry.value, true);
    }
    return const BirdResolvedLocation(LatLng(52.0693, 19.4803), false);
  }
}

class BirdSpeciesNames {
  static String toPolish(String en, String latin) {
    final byEnglish = <String, String>{
      'common shelduck': 'Ohar',
      'eurasian oystercatcher': 'Ostrygojad',
      'eurasian whimbrel': 'Kulik mniejszy',
      'eurasian whimbrels': 'Kulik mniejszy',
      'sandwich tern': 'Rybitwa czubata',
      'eurasian spoonbill': 'Warzęcha',
      'white-tailed eagle': 'Bielik',
      'greater spotted eagle': 'Orlik grubodzioby',
      'lesser spotted eagle': 'Orlik krzykliwy',
    };
    final byLatin = <String, String>{
      'tadorna tadorna': 'Ohar',
      'haematopus ostralegus': 'Ostrygojad',
      'numenius phaeopus': 'Kulik mniejszy',
      'thalasseus sandvicensis': 'Rybitwa czubata',
      'platalea leucorodia': 'Warzęcha',
      'haliaeetus albicilla': 'Bielik',
      'clanga clanga': 'Orlik grubodzioby',
      'clanga pomarina': 'Orlik krzykliwy',
    };
    return byEnglish[en.toLowerCase().trim()] ?? byLatin[latin.toLowerCase().trim()] ?? en;
  }

  static String group(String pl, String en) {
    final text = '$pl $en'.toLowerCase();
    if (text.contains('orlik') || text.contains('bielik') || text.contains('eagle') || text.contains('falcon')) return 'drapieżne';
    if (text.contains('sowa') || text.contains('owl')) return 'sowy';
    if (text.contains('rybitwa') || text.contains('tern') || text.contains('mewa') || text.contains('gull')) return 'mewy i rybitwy';
    if (text.contains('kulik') || text.contains('ostrygojad') || text.contains('siew') || text.contains('whimbrel') || text.contains('oystercatcher')) return 'siewkowe';
    if (text.contains('ohar') || text.contains('duck') || text.contains('shelduck')) return 'wodne';
    return 'inne';
  }

  static bool defaultSensitive(String pl, String latin) {
    final text = '$pl $latin'.toLowerCase();
    const keys = ['puchacz', 'sóweczka', 'włochatka', 'orlik', 'bielik', 'rybołów', 'bocian czarny', 'głuszec', 'cietrzew', 'clanga'];
    return keys.any(text.contains);
  }
}

String _normBird(String value) => value.trim().toLowerCase();

int? _intValue(dynamic value) {
  if (value == null) return null;
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value.toString());
}

double? _doubleValue(dynamic value) {
  if (value == null) return null;
  if (value is double) return value;
  if (value is int) return value.toDouble();
  if (value is num) return value.toDouble();
  return double.tryParse(value.toString());
}

LatLng _blurBirdPoint(double lat, double lng, {required String seed}) {
  var hash = 0;
  for (final unit in seed.codeUnits) {
    hash = 0x1fffffff & (hash + unit);
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    hash ^= (hash >> 6);
  }
  final angle = (hash % 360) * pi / 180.0;
  final meters = 1200 + (hash % 1200);
  final dLat = (meters * cos(angle)) / 111320.0;
  final dLng = (meters * sin(angle)) / (111320.0 * max(0.25, cos(lat * pi / 180.0).abs()));
  return LatLng(lat + dLat, lng + dLng);
}

class BirdObservationsMapPage extends StatefulWidget {
  const BirdObservationsMapPage({super.key});

  @override
  State<BirdObservationsMapPage> createState() => _BirdObservationsMapPageState();
}

class _BirdObservationsMapPageState extends State<BirdObservationsMapPage> {
  String search = '';
  bool showClanga = true;
  bool showOwn = true;
  bool onlyActive = false;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final all = state.visibleBirdObservations();
    final filtered = all.where((o) {
      final text = '${o.speciesName} ${o.speciesNameEn} ${o.latinName} ${o.locationName}'.toLowerCase();
      if (search.trim().isNotEmpty && !text.contains(search.trim().toLowerCase())) return false;
      if (!showClanga && o.source == BirdObservationSource.clanga) return false;
      if (!showOwn && o.source == BirdObservationSource.user) return false;
      if (onlyActive && o.status != BirdObservationStatus.active) return false;
      return o.locationResolved;
    }).toList();

    final markers = filtered.map((o) {
      final p = state.visibleBirdPoint(o);
      final sensitive = o.isSensitive || state.isBirdSpeciesSensitive(o.speciesName);
      final exact = state.canSeeExactBirdLocation(o);
      return Marker(
        point: p,
        width: 50,
        height: 50,
        child: GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BirdObservationDetailsPage(observation: o))),
          child: CircleAvatar(
            backgroundColor: sensitive && !exact ? Colors.orange.shade700 : AppTheme.green,
            child: Icon(sensitive && !exact ? Icons.visibility_off : Icons.flutter_dash, color: Colors.white),
          ),
        ),
      );
    }).toList();

    return Column(
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(
                          hintText: 'Szukaj gatunku albo miejsca',
                          prefixIcon: Icon(Icons.search),
                        ),
                        onChanged: (v) => setState(() => search = v),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      tooltip: 'Import z Clanga',
                      onPressed: () => state.importBirdObservationsFromClanga(),
                      icon: const Icon(Icons.sync),
                    ),
                    IconButton.outlined(
                      tooltip: 'Synchronizuj',
                      onPressed: () => state.syncBirdObservations(),
                      icon: const Icon(Icons.cloud_sync),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  children: [
                    FilterChip(selected: showClanga, onSelected: (v) => setState(() => showClanga = v), label: const Text('Clanga')),
                    FilterChip(selected: showOwn, onSelected: (v) => setState(() => showOwn = v), label: const Text('Własne')),
                    FilterChip(selected: onlyActive, onSelected: (v) => setState(() => onlyActive = v), label: const Text('Nadal jest')),
                  ],
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: FlutterMap(
            options: const MapOptions(initialCenter: LatLng(52.1, 19.4), initialZoom: 6),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'pl.bartoszlawicki.ptasia_mapa',
              ),
              MarkerLayer(markers: markers),
            ],
          ),
        ),
        SizedBox(
          height: 160,
          child: filtered.isEmpty
              ? const Center(child: Text('Brak obserwacji. Dodaj własną albo użyj importu z Clanga.'))
              : ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (_, i) => _BirdObservationTile(observation: filtered[i]),
                ),
        ),
      ],
    );
  }
}

class _BirdObservationTile extends StatelessWidget {
  const _BirdObservationTile({required this.observation});

  final BirdObservation observation;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final sensitive = observation.isSensitive || state.isBirdSpeciesSensitive(observation.speciesName);
    final exact = state.canSeeExactBirdLocation(observation);
    return ListTile(
      leading: Icon(sensitive && !exact ? Icons.visibility_off : Icons.flutter_dash, color: sensitive && !exact ? Colors.orange : AppTheme.green),
      title: Text('${observation.speciesName} · ${observation.count} os.', maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(
        '${observation.locationName} · ${DateFormat('dd.MM HH:mm').format(observation.observedAt)} · ${observation.source.label}${sensitive && !exact ? ' · punkt przybliżony' : ''}',
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: Text('${observation.confirmations.length}x'),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BirdObservationDetailsPage(observation: observation))),
    );
  }
}

class AddBirdObservationPage extends StatefulWidget {
  const AddBirdObservationPage({super.key});

  @override
  State<AddBirdObservationPage> createState() => _AddBirdObservationPageState();
}

class _AddBirdObservationPageState extends State<AddBirdObservationPage> {
  final species = TextEditingController();
  final latin = TextEditingController();
  final count = TextEditingController(text: '1');
  final place = TextEditingController();
  final note = TextEditingController();
  double? lat;
  double? lng;
  bool sensitive = false;
  BirdObservationStatus status = BirdObservationStatus.active;
  final photos = <String>[];

  @override
  void dispose() {
    species.dispose();
    latin.dispose();
    count.dispose();
    place.dispose();
    note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('Dodaj obserwację ptaka', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                TextField(
                  controller: species,
                  decoration: const InputDecoration(labelText: 'Gatunek', hintText: 'np. Ohar, Bielik, Warzęcha'),
                  onChanged: (v) => setState(() => sensitive = state.isBirdSpeciesSensitive(v)),
                ),
                const SizedBox(height: 10),
                TextField(controller: latin, decoration: const InputDecoration(labelText: 'Nazwa łacińska / opcjonalnie')),
                const SizedBox(height: 10),
                TextField(controller: count, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Liczba osobników')),
                const SizedBox(height: 10),
                TextField(controller: place, decoration: const InputDecoration(labelText: 'Miejsce', hintText: 'np. Beka, Mikoszewo, staw nr 3')),
                const SizedBox(height: 10),
                DropdownButtonFormField<BirdObservationStatus>(
                  value: status,
                  decoration: const InputDecoration(labelText: 'Status'),
                  items: BirdObservationStatus.values.map((s) => DropdownMenuItem(value: s, child: Text(s.label))).toList(),
                  onChanged: (v) => setState(() => status = v ?? BirdObservationStatus.unknown),
                ),
                SwitchListTile(
                  value: sensitive,
                  onChanged: (v) => setState(() => sensitive = v),
                  title: const Text('Gatunek wrażliwy'),
                  subtitle: const Text('Zwykli użytkownicy zobaczą tylko punkt przybliżony.'),
                ),
                Row(
                  children: [
                    Expanded(child: Text(lat == null ? 'Brak GPS' : 'GPS: ${lat!.toStringAsFixed(5)}, ${lng!.toStringAsFixed(5)}')),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final p = await _getLocationWithPrompt(context, state);
                        if (p != null) setState(() { lat = p.latitude; lng = p.longitude; });
                      },
                      icon: const Icon(Icons.my_location),
                      label: const Text('GPS'),
                    ),
                  ],
                ),
                TextField(controller: note, maxLines: 3, decoration: const InputDecoration(labelText: 'Opis / notatka')),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: Text('Zdjęcia: ${photos.length}')),
                    OutlinedButton.icon(
                      onPressed: _pickPhoto,
                      icon: const Icon(Icons.photo_camera),
                      label: const Text('Zdjęcie'),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: () => _save(context),
                  icon: const Icon(Icons.save),
                  label: const Text('Zapisz obserwację'),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _pickPhoto() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 1800);
    if (picked != null) setState(() => photos.add(picked.path));
  }

  Future<void> _save(BuildContext context) async {
    final state = AppStateScope.of(context);
    if (!_ensureLoggedInForChanges(context, state, 'dodanie obserwacji ptaka')) return;
    if (species.text.trim().isEmpty) {
      state.showError('Podaj gatunek ptaka.');
      return;
    }
    if (place.text.trim().isEmpty) {
      state.showError('Podaj miejsce obserwacji.');
      return;
    }

    final resolved = lat != null && lng != null;
    final fallback = BirdLocationResolver.resolve(place.text.trim());
    final point = resolved ? LatLng(lat!, lng!) : fallback.point;
    final observation = BirdObservation(
      id: const Uuid().v4(),
      speciesName: species.text.trim(),
      latinName: latin.text.trim(),
      birdGroup: BirdSpeciesNames.group(species.text, ''),
      count: int.tryParse(count.text.trim()) ?? 1,
      locationName: place.text.trim(),
      latitude: point.latitude,
      longitude: point.longitude,
      observedAt: DateTime.now(),
      source: BirdObservationSource.user,
      observerName: state.currentUser?.email ?? 'Użytkownik',
      status: status,
      isSensitive: sensitive || state.isBirdSpeciesSensitive(species.text),
      locationResolved: resolved || fallback.resolved,
      locationAccuracy: resolved ? 'GPS' : fallback.resolved ? 'z nazwy miejsca' : 'do ustawienia ręcznie',
      ownerId: state.currentUser?.id ?? state.localGuestId ?? '',
      ownerEmail: state.currentUser?.email ?? '',
      photoPaths: List<String>.from(photos),
    );

    await state.addBirdObservation(observation);
    species.clear();
    latin.clear();
    count.text = '1';
    place.clear();
    note.clear();
    photos.clear();
    setState(() { lat = null; lng = null; sensitive = false; status = BirdObservationStatus.active; });
    state.showInfo('Dodano obserwację ptaka.');
  }
}

class BirdObservationDetailsPage extends StatelessWidget {
  const BirdObservationDetailsPage({super.key, required this.observation});

  final BirdObservation observation;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final point = state.visibleBirdPoint(observation);
    final sensitive = observation.isSensitive || state.isBirdSpeciesSensitive(observation.speciesName);
    final exact = state.canSeeExactBirdLocation(observation);
    return Scaffold(
      appBar: AppBar(title: Text(observation.speciesName)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
          children: [
            SizedBox(
              height: 210,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: FlutterMap(
                  options: MapOptions(initialCenter: point, initialZoom: 13),
                  children: [
                    TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'pl.bartoszlawicki.ptasia_mapa'),
                    MarkerLayer(markers: [Marker(point: point, width: 48, height: 48, child: const Icon(Icons.location_on, color: Colors.red, size: 46))]),
                  ],
                ),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${observation.speciesName} · ${observation.count} os.', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                    if (observation.latinName.isNotEmpty) Text(observation.latinName, style: const TextStyle(fontStyle: FontStyle.italic)),
                    const SizedBox(height: 8),
                    _BirdInfoRow('Miejsce', observation.locationName),
                    _BirdInfoRow('Data', DateFormat('dd.MM.yyyy HH:mm').format(observation.observedAt)),
                    _BirdInfoRow('Status', observation.status.label),
                    _BirdInfoRow('Źródło', observation.source.label),
                    _BirdInfoRow('Dokładność', sensitive && !exact ? 'punkt przybliżony' : observation.locationAccuracy),
                    _BirdInfoRow('GPS widoczny', '${point.latitude.toStringAsFixed(5)}, ${point.longitude.toStringAsFixed(5)}'),
                    if (observation.sourceUrl.isNotEmpty) _BirdInfoRow('Link', observation.sourceUrl),
                  ],
                ),
              ),
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.icon(onPressed: () => _confirm(context, true), icon: const Icon(Icons.visibility), label: const Text('Też widziałem')),
                OutlinedButton.icon(onPressed: () => _confirm(context, false), icon: const Icon(Icons.visibility_off), label: const Text('Nie ma już')),
                OutlinedButton.icon(onPressed: () => _confirm(context, null), icon: const Icon(Icons.help_outline), label: const Text('Nie wiem')),
              ],
            ),
            const SizedBox(height: 12),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Text('Potwierdzenia', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            ),
            if (observation.confirmations.isEmpty)
              const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('Brak potwierdzeń.'))),
            for (final c in observation.confirmations)
              Card(
                child: ListTile(
                  leading: Icon(c.stillPresent == true ? Icons.check_circle : c.stillPresent == false ? Icons.cancel : Icons.help),
                  title: Text(c.displayName.isEmpty ? 'Użytkownik' : c.displayName),
                  subtitle: Text('${DateFormat('dd.MM.yyyy HH:mm').format(c.seenAt)}${c.comment.isNotEmpty ? '\n${c.comment}' : ''}'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirm(BuildContext context, bool? stillPresent) async {
    final state = AppStateScope.of(context);
    if (!_ensureLoggedInForChanges(context, state, 'potwierdzenie obserwacji')) return;
    final controller = TextEditingController();
    final comment = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(stillPresent == true ? 'Też widziałeś?' : stillPresent == false ? 'Nie ma już ptaka?' : 'Dodaj informację'),
        content: TextField(controller: controller, maxLines: 3, decoration: const InputDecoration(labelText: 'Komentarz / godzina / kierunek')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Anuluj')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Zapisz')),
        ],
      ),
    );
    if (comment == null) return;
    await state.confirmBirdObservation(observation, stillPresent: stillPresent, comment: comment);
  }
}

class _BirdInfoRow extends StatelessWidget {
  const _BirdInfoRow(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    if (value.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: RichText(
        text: TextSpan(
          style: DefaultTextStyle.of(context).style,
          children: [
            TextSpan(text: '$label: ', style: const TextStyle(fontWeight: FontWeight.bold)),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }
}

class BirdSensitiveAdminPage extends StatefulWidget {
  const BirdSensitiveAdminPage({super.key});

  @override
  State<BirdSensitiveAdminPage> createState() => _BirdSensitiveAdminPageState();
}

class _BirdSensitiveAdminPageState extends State<BirdSensitiveAdminPage> {
  final speciesController = TextEditingController();
  final emailController = TextEditingController();

  @override
  void dispose() {
    speciesController.dispose();
    emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final species = state.sensitiveBirdSpecies.toList()..sort();
    final email = emailController.text.trim().toLowerCase();
    final access = state.sensitiveBirdAccessByEmail[email] ?? const <String>{};
    return Scaffold(
      appBar: AppBar(title: const Text('Ptaki wrażliwe')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Gatunki z ukrytą dokładną lokalizacją', style: TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 10),
                    TextField(controller: speciesController, decoration: const InputDecoration(labelText: 'Dodaj gatunek, np. Puchacz')),
                    const SizedBox(height: 10),
                    FilledButton.icon(
                      onPressed: () {
                        state.setSensitiveBirdSpecies(speciesController.text, true);
                        speciesController.clear();
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Dodaj jako wrażliwy'),
                    ),
                    const SizedBox(height: 10),
                    for (final s in species)
                      SwitchListTile(
                        value: true,
                        title: Text(s),
                        subtitle: const Text('Dokładny punkt tylko dla uprawnionych'),
                        onChanged: (v) => state.setSensitiveBirdSpecies(s, v),
                      ),
                  ],
                ),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Dostęp użytkownika do dokładnych punktów', style: TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 10),
                    TextField(
                      controller: emailController,
                      decoration: const InputDecoration(labelText: 'Email użytkownika'),
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 10),
                    CheckboxListTile(
                      value: access.map(_normBird).contains('*'),
                      title: const Text('Dostęp do wszystkich gatunków wrażliwych'),
                      onChanged: email.isEmpty ? null : (v) => state.setSensitiveBirdAccess(email: email, speciesName: '*', allowed: v == true),
                    ),
                    for (final s in species)
                      CheckboxListTile(
                        value: access.map(_normBird).contains(_normBird(s)),
                        title: Text(s),
                        onChanged: email.isEmpty ? null : (v) => state.setSensitiveBirdAccess(email: email, speciesName: s, allowed: v == true),
                      ),
                  ],
                ),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Eksport obserwacji', style: TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: () => Clipboard.setData(ClipboardData(text: state.exportBirdObservationsCsv())).then((_) => state.showInfo('Skopiowano CSV obserwacji.')),
                      icon: const Icon(Icons.table_chart),
                      label: const Text('Kopiuj CSV obserwacji'),
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: () => Clipboard.setData(ClipboardData(text: state.exportBirdObservationsKml())).then((_) => state.showInfo('Skopiowano KML obserwacji.')),
                      icon: const Icon(Icons.map),
                      label: const Text('Kopiuj KML obserwacji'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

bool _ensureLoggedInForChanges(BuildContext context, AppState state, String action) {
  if (state.canCreateObjects) return true;

  state.showInfo('Jesteś w trybie Gość. Możesz oglądać obiekty na mapie, ale $action wymaga zalogowania.');
  Future.microtask(() {
    if (context.mounted) _showAccountDialog(context);
  });
  return false;
}

Future<void> _addPhotoToExistingSite(BuildContext context, NestSite site, ImageSource source) async {
  final state = AppStateScope.of(context);
  if (!state.canEdit(site)) {
    state.showInfo('Gość może tylko oglądać obiekty. Dodawanie zdjęć wymaga zalogowania i uprawnień do obiektu.');
    return;
  }

  try {
    final picked = await ImagePicker().pickImage(source: source, imageQuality: 82, maxWidth: 1800);
    if (picked == null) return;

    site.photoPaths.add(picked.path);
    await state.updateSite(site);

    if (!context.mounted) return;
    state.showInfo('Dodano zdjęcie do obiektu.');
  } catch (e) {
    state.showError('Nie udało się dodać zdjęcia: $e');
  }
}

Future<void> _openGoogleMapsTo(NestSite site) async {
  final uri = Uri.parse(
    'https://www.google.com/maps/dir/?api=1&destination=${site.latitude},${site.longitude}&travelmode=walking',
  );

  if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
    final fallback = Uri.parse('https://www.google.com/maps/search/?api=1&query=${site.latitude},${site.longitude}');
    await launchUrl(fallback, mode: LaunchMode.externalApplication);
  }
}


Future<LatLng?> _getLocationWithPrompt(BuildContext context, AppState state) async {
  try {
    return await state.currentLocation();
  } catch (e) {
    final message = e.toString();
    if (!context.mounted) return null;

    final lower = message.toLowerCase();
    final needsLocationSettings = lower.contains('wyłączona') ||
        lower.contains('location services') ||
        lower.contains('service');

    final needsAppSettings = lower.contains('zablokowany') ||
        lower.contains('deniedforever') ||
        lower.contains('na stałe');

    if (needsLocationSettings || needsAppSettings) {
      final open = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(needsLocationSettings ? 'Włączyć GPS?' : 'Nadać zgodę na GPS?'),
          content: Text(
            needsLocationSettings
                ? 'Ta funkcja potrzebuje lokalizacji. Włącz GPS w ustawieniach telefonu i wróć do aplikacji.'
                : 'Ta funkcja potrzebuje zgody na lokalizację. Otwórz ustawienia aplikacji i nadaj zgodę GPS.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Anuluj')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Otwórz ustawienia')),
          ],
        ),
      );

      if (open == true) {
        if (needsLocationSettings) {
          await Geolocator.openLocationSettings();
        } else {
          await Geolocator.openAppSettings();
        }
      }
      return null;
    }

    state.showError('Nie udało się pobrać GPS: $message');
    return null;
  }
}

bool _siteNeedsRepair(NestSite site) {
  final status = site.technicalStatus.toLowerCase();
  return site.repairNeeded ||
      site.damageDescription.trim().isNotEmpty ||
      status.contains('uszkodz') ||
      status.contains('zabrudz') ||
      status.contains('spad') ||
      status.contains('zalanie') ||
      status.contains('napraw');
}

Inspection? _latestCleanedInspection(NestSite site) {
  final cleaned = site.inspections.where((i) => i.cleaned && !i.deleted).toList()
    ..sort((a, b) => b.date.compareTo(a.date));
  return cleaned.isEmpty ? null : cleaned.first;
}

DateTime _cleaningSeasonStart(DateTime now) {
  final thisYearStart = DateTime(now.year, 10, 16);
  final previousSeasonEndExclusive = DateTime(now.year, 3, 1);
  if (!now.isBefore(thisYearStart)) return thisYearStart;
  if (now.isBefore(previousSeasonEndExclusive)) return DateTime(now.year - 1, 10, 16);
  return thisYearStart;
}

DateTime _cleaningSeasonEndExclusive(DateTime start) => DateTime(start.year + 1, 3, 1);

bool _isCleaningPeriod(DateTime now) {
  final start = _cleaningSeasonStart(now);
  final end = _cleaningSeasonEndExclusive(start);
  return !now.isBefore(start) && now.isBefore(end);
}

bool _cleanedInSelectedSeason(NestSite site, DateTime now) {
  final start = _cleaningSeasonStart(now);
  final end = _cleaningSeasonEndExclusive(start);
  return site.inspections.any((i) => i.cleaned && !i.deleted && !i.date.isBefore(start) && i.date.isBefore(end));
}

int _daysBetweenDates(DateTime from, DateTime to) {
  final a = DateTime(from.year, from.month, from.day);
  final b = DateTime(to.year, to.month, to.day);
  return max(0, b.difference(a).inDays);
}

String _cleaningCounterText(DateTime now) {
  final start = _cleaningSeasonStart(now);
  final endExclusive = _cleaningSeasonEndExclusive(start);
  final endVisible = endExclusive.subtract(const Duration(days: 1));
  final format = DateFormat('dd.MM.yyyy');

  if (_isCleaningPeriod(now)) {
    final days = _daysBetweenDates(now, endExclusive);
    return 'Trwa okres czyszczenia. Do końca zostało $days dni (do ${format.format(endVisible)}).';
  }

  final days = _daysBetweenDates(now, start);
  return 'Do okresu czyszczenia zostało $days dni. Start: ${format.format(start)}.';
}

class UpdateInfo {
  UpdateInfo({
    required this.versionCode,
    required this.versionName,
    required this.apkUrl,
    this.notes = '',
  });

  final int versionCode;
  final String versionName;
  final String apkUrl;
  final String notes;

  factory UpdateInfo.fromJson(Map<String, dynamic> json) {
    int parseCode(dynamic value) {
      if (value is num) return value.toInt();
      return int.tryParse(value?.toString() ?? '') ?? 0;
    }

    return UpdateInfo(
      versionCode: parseCode(json['versionCode'] ?? json['version_code'] ?? json['build']),
      versionName: (json['versionName'] ?? json['version_name'] ?? json['version'] ?? '').toString(),
      apkUrl: (json['apkUrl'] ?? json['apk_url'] ?? json['url'] ?? json['downloadUrl'] ?? '').toString(),
      notes: (json['notes'] ?? json['opis'] ?? json['changelog'] ?? '').toString(),
    );
  }
}

class NearbySite {
  const NearbySite({
    required this.site,
    required this.distanceMeters,
  });

  final NestSite site;
  final double distanceMeters;

  String get distanceText {
    if (distanceMeters < 10) return '${distanceMeters.toStringAsFixed(1)} m';
    return '${distanceMeters.round()} m';
  }
}

class NestSite {
  NestSite({
    required this.id,
    required this.name,
    required this.type,
    required this.latitude,
    required this.longitude,
    this.placeDescription = '',
    this.technicalStatus = 'Dobry',
    this.repairNeeded = false,
    this.damageDescription = '',
    this.notes = '',
    this.reportStatus = 'Zgłoszona',
    this.deleteRequested = false,
    this.deleteReason = '',
    this.hiddenFromUsers = false,
    this.deleted = false,
    this.ownerId = '',
    this.ownerEmail = '',
    required this.createdAt,
    required this.updatedAt,
    this.locallyChanged = false,
    List<String>? photoPaths,
    List<Inspection>? inspections,
  })  : photoPaths = photoPaths ?? [],
        inspections = inspections ?? [];

  String id;
  String name;
  String type;
  double latitude;
  double longitude;
  String placeDescription;
  String technicalStatus;
  bool repairNeeded;
  String damageDescription;
  String notes;
  String reportStatus;
  bool deleteRequested;
  String deleteReason;
  bool hiddenFromUsers;
  bool deleted;
  String ownerId;
  String ownerEmail;
  DateTime createdAt;
  DateTime updatedAt;
  bool locallyChanged;
  List<String> photoPaths;
  List<Inspection> inspections;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type,
        'latitude': latitude,
        'longitude': longitude,
        'placeDescription': placeDescription,
        'technicalStatus': technicalStatus,
        'repairNeeded': repairNeeded,
        'damageDescription': damageDescription,
        'notes': notes,
        'reportStatus': reportStatus,
        'deleteRequested': deleteRequested,
        'deleteReason': deleteReason,
        'hiddenFromUsers': hiddenFromUsers,
        'deleted': deleted,
        'ownerId': ownerId,
        'ownerEmail': ownerEmail,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'locallyChanged': locallyChanged,
        'photoPaths': photoPaths,
        'inspections': inspections.map((e) => e.toJson()).toList(),
      };

  factory NestSite.fromJson(Map<String, dynamic> j) => NestSite(
        id: _string(j['id']),
        name: _string(j['name'], fallback: 'Obiekt'),
        type: _string(j['type'], fallback: 'Budka lęgowa'),
        latitude: _double(j['latitude']),
        longitude: _double(j['longitude']),
        placeDescription: _string(j['placeDescription']),
        technicalStatus: _string(j['technicalStatus'], fallback: 'Dobry'),
        repairNeeded: _bool(j['repairNeeded']),
        damageDescription: _string(j['damageDescription']),
        notes: _string(j['notes']),
        reportStatus: _string(j['reportStatus'], fallback: 'Zgłoszona'),
        deleteRequested: _bool(j['deleteRequested']),
        deleteReason: _string(j['deleteReason']),
        hiddenFromUsers: _bool(j['hiddenFromUsers']),
        deleted: _bool(j['deleted']),
        ownerId: _string(j['ownerId']),
        ownerEmail: _string(j['ownerEmail']),
        createdAt: _date(j['createdAt']),
        updatedAt: _date(j['updatedAt']),
        locallyChanged: _bool(j['locallyChanged']),
        photoPaths: _stringList(j['photoPaths']),
        inspections: (j['inspections'] as List? ?? [])
            .whereType<Map>()
            .map((e) => Inspection.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );

  Map<String, dynamic> toServerMap() => {
        'id': id,
        'name': name,
        'type': type,
        'latitude': latitude,
        'longitude': longitude,
        'place_description': placeDescription,
        'technical_status': technicalStatus,
        'repair_needed': repairNeeded,
        'damage_description': damageDescription,
        'notes': notes,
        'report_status': reportStatus,
        'delete_requested': deleteRequested,
        'delete_reason': deleteReason,
        'hidden_from_users': hiddenFromUsers,
        'deleted': deleted,
        'owner_id': ownerId,
        'owner_email': ownerEmail,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'photo_urls': photoPaths,
      };

  factory NestSite.fromServerMap(Map<String, dynamic> j) => NestSite(
        id: _string(j['id']),
        name: _string(j['name'], fallback: 'Obiekt'),
        type: _string(j['type'], fallback: 'Budka lęgowa'),
        latitude: _double(j['latitude']),
        longitude: _double(j['longitude']),
        placeDescription: _string(j['place_description']),
        technicalStatus: _string(j['technical_status'], fallback: 'Dobry'),
        repairNeeded: _bool(j['repair_needed']),
        damageDescription: _string(j['damage_description']),
        notes: _string(j['notes']),
        reportStatus: _string(j['report_status'], fallback: 'Zgłoszona'),
        deleteRequested: _bool(j['delete_requested']),
        deleteReason: _string(j['delete_reason']),
        hiddenFromUsers: _bool(j['hidden_from_users']),
        deleted: _bool(j['deleted']),
        ownerId: _string(j['owner_id']),
        ownerEmail: _string(j['owner_email']),
        createdAt: _date(j['created_at']),
        updatedAt: _date(j['updated_at']),
        photoPaths: _stringList(j['photo_urls']),
      );
}

class Inspection {
  Inspection({
    required this.id,
    required this.date,
    this.inspector = '',
    this.cleaned = false,
    this.cleanedBy = '',
    this.condition = 'Dobry',
    this.birdsPresent = false,
    this.birdSpecies = '',
    this.eggsCount = 0,
    this.chicksCount = 0,
    this.adultsCount = 0,
    this.notes = '',
    this.deleted = false,
    this.locallyChanged = false,
  });

  String id;
  DateTime date;
  String inspector;
  bool cleaned;
  String cleanedBy;
  String condition;
  bool birdsPresent;
  String birdSpecies;
  int eggsCount;
  int chicksCount;
  int adultsCount;
  String notes;
  bool deleted;
  bool locallyChanged;

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'inspector': inspector,
        'cleaned': cleaned,
        'cleanedBy': cleanedBy,
        'condition': condition,
        'birdsPresent': birdsPresent,
        'birdSpecies': birdSpecies,
        'eggsCount': eggsCount,
        'chicksCount': chicksCount,
        'adultsCount': adultsCount,
        'notes': notes,
        'deleted': deleted,
        'locallyChanged': locallyChanged,
      };

  factory Inspection.fromJson(Map<String, dynamic> j) => Inspection(
        id: _string(j['id']),
        date: _date(j['date']),
        inspector: _string(j['inspector']),
        cleaned: _bool(j['cleaned']),
        cleanedBy: _string(j['cleanedBy']),
        condition: _string(j['condition'], fallback: 'Dobry'),
        birdsPresent: _bool(j['birdsPresent']),
        birdSpecies: _string(j['birdSpecies']),
        eggsCount: _int(j['eggsCount']),
        chicksCount: _int(j['chicksCount']),
        adultsCount: _int(j['adultsCount']),
        notes: _string(j['notes']),
        deleted: _bool(j['deleted']),
        locallyChanged: _bool(j['locallyChanged']),
      );

  Map<String, dynamic> toServerMap(String siteId) => {
        'id': id,
        'nest_site_id': siteId,
        'date': date.toIso8601String(),
        'inspector': inspector,
        'cleaned': cleaned,
        'cleaned_by': cleanedBy,
        'condition': condition,
        'birds_present': birdsPresent,
        'bird_species': birdSpecies,
        'eggs_count': eggsCount,
        'chicks_count': chicksCount,
        'adults_count': adultsCount,
        'notes': notes,
        'deleted': deleted,
        'updated_at': DateTime.now().toIso8601String(),
      };

  factory Inspection.fromServerMap(Map<String, dynamic> j) => Inspection(
        id: _string(j['id']),
        date: _date(j['date']),
        inspector: _string(j['inspector']),
        cleaned: _bool(j['cleaned']),
        cleanedBy: _string(j['cleaned_by']),
        condition: _string(j['condition'], fallback: 'Dobry'),
        birdsPresent: _bool(j['birds_present']),
        birdSpecies: _string(j['bird_species']),
        eggsCount: _int(j['eggs_count']),
        chicksCount: _int(j['chicks_count']),
        adultsCount: _int(j['adults_count']),
        notes: _string(j['notes']),
        deleted: _bool(j['deleted']),
      );
}

String _string(dynamic v, {String fallback = ''}) => v?.toString() ?? fallback;
double _double(dynamic v) => v is num ? v.toDouble() : double.tryParse(v?.toString() ?? '') ?? 0;
int _int(dynamic v) => v is num ? v.toInt() : int.tryParse(v?.toString() ?? '') ?? 0;
bool _bool(dynamic v) => v == true || v == 1 || v == 'true';
DateTime _date(dynamic v) => DateTime.tryParse(v?.toString() ?? '') ?? DateTime.now();
List<String> _stringList(dynamic v) {
  if (v is List) {
    return v.map((e) => e.toString()).where((e) => e.trim().isNotEmpty).toList();
  }
  if (v is String && v.trim().isNotEmpty) {
    try {
      final decoded = jsonDecode(v);
      if (decoded is List) {
        return decoded.map((e) => e.toString()).where((e) => e.trim().isNotEmpty).toList();
      }
    } catch (_) {}
    return v.split('|').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  }
  return <String>[];
}


const objectTypes = [
  'Budka lęgowa',
  'Dziupla naturalna',
  'Dziupla sztuczna',
  'Karmnik',
  'Schronienie',
  'Inne',
];

const technicalStatuses = [
  'Dobry',
  'Do kontroli',
  'Zabrudzona',
  'Uszkodzona',
  'Zalanie',
  'Spadła',
  'Zajęta przez inne zwierzę',
];

const birdSpecies = [
  'Bocian biały — Ciconia ciconia',
  'Bocian czarny — Ciconia nigra',
  'Łabędź niemy — Cygnus olor',
  'Gęgawa — Anser anser',
  'Krzyżówka — Anas platyrhynchos',
  'Cyranka — Spatula querquedula',
  'Gągoł — Bucephala clangula',
  'Nurogęś — Mergus merganser',
  'Kania ruda — Milvus milvus',
  'Kania czarna — Milvus migrans',
  'Bielik — Haliaeetus albicilla',
  'Błotniak stawowy — Circus aeruginosus',
  'Jastrząb — Accipiter gentilis',
  'Krogulec — Accipiter nisus',
  'Myszołów — Buteo buteo',
  'Orlik krzykliwy — Clanga pomarina',
  'Pustułka — Falco tinnunculus',
  'Kobuz — Falco subbuteo',
  'Sokół wędrowny — Falco peregrinus',
  'Kuropatwa — Perdix perdix',
  'Przepiórka — Coturnix coturnix',
  'Bażant — Phasianus colchicus',
  'Wodnik — Rallus aquaticus',
  'Derkacz — Crex crex',
  'Łyska — Fulica atra',
  'Czajka — Vanellus vanellus',
  'Sieweczka rzeczna — Charadrius dubius',
  'Kszyk — Gallinago gallinago',
  'Rycyk — Limosa limosa',
  'Krwawodziób — Tringa totanus',
  'Mewa śmieszka — Chroicocephalus ridibundus',
  'Rybitwa rzeczna — Sterna hirundo',
  'Grzywacz — Columba palumbus',
  'Sierpówka — Streptopelia decaocto',
  'Turkawka — Streptopelia turtur',
  'Kukułka — Cuculus canorus',
  'Płomykówka — Tyto alba',
  'Puszczyk — Strix aluco',
  'Uszatka — Asio otus',
  'Sóweczka — Glaucidium passerinum',
  'Włochatka — Aegolius funereus',
  'Lelek — Caprimulgus europaeus',
  'Jerzyk — Apus apus',
  'Zimorodek — Alcedo atthis',
  'Żołna — Merops apiaster',
  'Dudek — Upupa epops',
  'Krętogłów — Jynx torquilla',
  'Dzięcioł zielony — Picus viridis',
  'Dzięcioł czarny — Dryocopus martius',
  'Dzięcioł duży — Dendrocopos major',
  'Dzięcioł średni — Dendrocoptes medius',
  'Dzięciołek — Dryobates minor',
  'Skowronek — Alauda arvensis',
  'Brzegówka — Riparia riparia',
  'Dymówka — Hirundo rustica',
  'Oknówka — Delichon urbicum',
  'Świergotek drzewny — Anthus trivialis',
  'Pliszka siwa — Motacilla alba',
  'Pliszka żółta — Motacilla flava',
  'Strzyżyk — Troglodytes troglodytes',
  'Pokrzywnica — Prunella modularis',
  'Rudzik — Erithacus rubecula',
  'Słowik szary — Luscinia luscinia',
  'Słowik rdzawy — Luscinia megarhynchos',
  'Kopciuszek — Phoenicurus ochruros',
  'Pleszka — Phoenicurus phoenicurus',
  'Pokląskwa — Saxicola rubetra',
  'Kląskawka — Saxicola rubicola',
  'Białorzytka — Oenanthe oenanthe',
  'Kos — Turdus merula',
  'Kwiczoł — Turdus pilaris',
  'Drozd śpiewak — Turdus philomelos',
  'Paszkot — Turdus viscivorus',
  'Świerszczak — Locustella naevia',
  'Strumieniówka — Locustella fluviatilis',
  'Rokitniczka — Acrocephalus schoenobaenus',
  'Trzcinniczek — Acrocephalus scirpaceus',
  'Łozówka — Acrocephalus palustris',
  'Zaganiacz — Hippolais icterina',
  'Jarzębatka — Curruca nisoria',
  'Piegża — Curruca curruca',
  'Cierniówka — Curruca communis',
  'Gajówka — Sylvia borin',
  'Kapturka — Sylvia atricapilla',
  'Świstunka leśna — Phylloscopus sibilatrix',
  'Pierwiosnek — Phylloscopus collybita',
  'Piecuszek — Phylloscopus trochilus',
  'Mysikrólik — Regulus regulus',
  'Zniczek — Regulus ignicapilla',
  'Muchołówka szara — Muscicapa striata',
  'Muchołówka mała — Ficedula parva',
  'Muchołówka żałobna — Ficedula hypoleuca',
  'Muchołówka białoszyja — Ficedula albicollis',
  'Raniuszek — Aegithalos caudatus',
  'Sikora uboga — Poecile palustris',
  'Czarnogłówka — Poecile montanus',
  'Sikora czubatka — Lophophanes cristatus',
  'Sosnówka — Periparus ater',
  'Modraszka — Cyanistes caeruleus',
  'Bogatka — Parus major',
  'Kowalik — Sitta europaea',
  'Pełzacz leśny — Certhia familiaris',
  'Pełzacz ogrodowy — Certhia brachydactyla',
  'Remiz — Remiz pendulinus',
  'Wilga — Oriolus oriolus',
  'Gąsiorek — Lanius collurio',
  'Sójka — Garrulus glandarius',
  'Sroka — Pica pica',
  'Orzechówka — Nucifraga caryocatactes',
  'Kawka — Coloeus monedula',
  'Gawron — Corvus frugilegus',
  'Wrona siwa — Corvus cornix',
  'Kruk — Corvus corax',
  'Szpak — Sturnus vulgaris',
  'Wróbel — Passer domesticus',
  'Mazurek — Passer montanus',
  'Zięba — Fringilla coelebs',
  'Jer — Fringilla montifringilla',
  'Kulczyk — Serinus serinus',
  'Dzwoniec — Chloris chloris',
  'Szczygieł — Carduelis carduelis',
  'Czyż — Spinus spinus',
  'Makolągwa — Linaria cannabina',
  'Czeczotka — Acanthis flammea',
  'Krzyżodziób świerkowy — Loxia curvirostra',
  'Dziwonia — Carpodacus erythrinus',
  'Gil — Pyrrhula pyrrhula',
  'Grubodziób — Coccothraustes coccothraustes',
  'Trznadel — Emberiza citrinella',
  'Potrzos — Emberiza schoeniclus',
  'Ortolan — Emberiza hortulana',
];

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final isAdmin = state.isAdmin;

    final update = state.availableUpdate;
    if (update != null && !state.updateDialogShown) {
      state.markUpdateDialogShown();
      Future.microtask(() {
        if (context.mounted) _showUpdateDialog(context, update);
      });
    }

    final pages = <Widget>[
      const MapPage(),
      const BirdObservationsMapPage(),
      const AddBirdObservationPage(),
      const ListPage(),
      const NearbyPage(),
      const RepairPage(),
      const CleaningPage(),
      if (isAdmin) const AdminPage(),
    ];

    final items = <NavigationDestination>[
      const NavigationDestination(icon: Icon(Icons.map), label: 'Budki'),
      const NavigationDestination(icon: Icon(Icons.travel_explore), label: 'Ptaki'),
      const NavigationDestination(icon: Icon(Icons.add_location_alt), label: 'Dodaj'),
      const NavigationDestination(icon: Icon(Icons.list_alt), label: 'Lista'),
      const NavigationDestination(icon: Icon(Icons.near_me), label: 'Blisko'),
      const NavigationDestination(icon: Icon(Icons.build_circle_outlined), label: 'Naprawy'),
      const NavigationDestination(icon: Icon(Icons.cleaning_services), label: 'Czyść'),
      if (isAdmin) const NavigationDestination(icon: Icon(Icons.admin_panel_settings), label: 'Admin'),
    ];

    if (state.currentTab >= pages.length) {
      Future.microtask(() => state.setTab(0));
    }

    return Scaffold(
      appBar: AppBar(
        flexibleSpace: const _ForestGradient(),
        title: _AppTitle(state: state),
        actions: [
          IconButton(
            onPressed: () => _showInfoDialog(context),
            icon: const Icon(Icons.info_outline),
          ),
          IconButton(
            tooltip: 'Sprawdź aktualizację',
            onPressed: state.checkingUpdate ? null : () => state.checkForUpdates(manual: true),
            icon: Icon(state.checkingUpdate ? Icons.hourglass_top : Icons.system_update_alt),
          ),
          IconButton(
            tooltip: state.loggedIn ? 'Konto / wyloguj' : 'Zaloguj / zarejestruj',
            onPressed: () => _showAccountDialog(context),
            icon: Icon(state.loggedIn ? Icons.account_circle : Icons.login),
          ),
          IconButton(
            tooltip: state.isAdmin ? 'Wyłącz admina' : 'Włącz admina',
            onPressed: () {
              if (state.isAdmin) {
                state.disableAdmin();
              } else {
                _showAdminPasswordDialog(context);
              }
            },
            icon: Icon(state.isAdmin ? Icons.shield : Icons.shield_outlined),
          ),
        ],
      ),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            if (state.errorMessage != null || state.infoMessage != null)
              MessageBanner(
                text: state.errorMessage ?? state.infoMessage!,
                error: state.errorMessage != null,
                onClose: state.clearMessages,
              ),
            Expanded(child: pages[min(state.currentTab, pages.length - 1)]),
            const PtasiaStrefaBanner(),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 0, 8, 4),
          child: NavigationBar(
            height: 72,
            selectedIndex: min(state.currentTab, items.length - 1),
            onDestinationSelected: state.setTab,
            destinations: items,
          ),
        ),
      ),
    );
  }
}

class _AppTitle extends StatelessWidget {
  const _AppTitle({required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Text('🐦', style: TextStyle(fontSize: 22)),
        const SizedBox(width: 8),
        const Flexible(
          child: Text(
            'Ptasia Mapa',
            overflow: TextOverflow.ellipsis,
          ),
        ),
        const SizedBox(width: 8),
        _RoleChip(label: state.roleLabel, admin: state.isAdmin),
      ],
    );
  }
}

class _RoleChip extends StatelessWidget {
  const _RoleChip({required this.label, required this.admin});

  final String label;
  final bool admin;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 98),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.18),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withOpacity(0.20)),
      ),
      child: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 11),
      ),
    );
  }
}


class MessageBanner extends StatelessWidget {
  const MessageBanner({super.key, required this.text, required this.error, required this.onClose});

  final String text;
  final bool error;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: error ? Colors.red.shade50 : Colors.green.shade50,
      child: ListTile(
        dense: true,
        leading: Icon(error ? Icons.error_outline : Icons.check_circle_outline, color: error ? Colors.red : Colors.green),
        title: Text(text, maxLines: 3, overflow: TextOverflow.ellipsis),
        trailing: IconButton(onPressed: onClose, icon: const Icon(Icons.close)),
      ),
    );
  }
}

class PtasiaStrefaBanner extends StatelessWidget {
  const PtasiaStrefaBanner({super.key, this.compact = true});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Padding(
      padding: EdgeInsets.fromLTRB(12, compact ? 4 : 8, 12, compact ? 10 : 12),
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFFF8E5), Color(0xFFE7F5D8), Color(0xFFD9EFCB)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0xFFCDE5B7)),
          boxShadow: const [BoxShadow(color: Color(0x18000000), blurRadius: 16, offset: Offset(0, 7))],
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 10, vertical: compact ? 7 : 11),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  'assets/ptasia_strefa_logo.png',
                  width: compact ? 36 : 44,
                  height: compact ? 36 : 44,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => CircleAvatar(
                    radius: compact ? 18 : 22,
                    backgroundColor: primary.withOpacity(0.12),
                    child: Icon(Icons.flutter_dash, color: primary),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Ptasia Strefa',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF184D2A),
                      ),
                ),
              ),
              const SizedBox(width: 6),
              _BannerButton(
                tooltip: 'Otwórz stronę Ptasia Strefa',
                label: 'WWW',
                icon: Icons.language,
                onTap: () => _openUrl('https://ptasiastrefa.pl/'),
              ),
              const SizedBox(width: 6),
              _BannerButton(
                tooltip: 'Otwórz YouTube Ptasia Strefa',
                label: 'YT',
                icon: Icons.play_circle_fill,
                onTap: () => _openUrl('https://www.youtube.com/@ptasiastrefa'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BannerButton extends StatelessWidget {
  const _BannerButton({required this.tooltip, required this.label, required this.icon, required this.onTap});

  final String tooltip;
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.86),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFD3E7C5)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: const Color(0xFF0B7A3B)),
              const SizedBox(width: 4),
              Text(label, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0B7A3B))),
            ],
          ),
        ),
      ),
    );
  }
}


Future<void> _openUrl(String url) async {
  final uri = Uri.parse(url);
  final tries = <LaunchMode>[
    LaunchMode.externalApplication,
    LaunchMode.inAppBrowserView,
    LaunchMode.platformDefault,
  ];

  for (final mode in tries) {
    try {
      final ok = await launchUrl(uri, mode: mode);
      if (ok) return;
    } catch (_) {}
  }

  if (url.contains('@ptasiastrefa')) {
    final fallback = Uri.parse('https://www.youtube.com/channel/UC13xLJTa9qif7DarMrFmUqQ');
    for (final mode in tries) {
      try {
        final ok = await launchUrl(fallback, mode: mode);
        if (ok) return;
      } catch (_) {}
    }
  }
}


class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  final MapController controller = MapController();
  LatLng center = const LatLng(54.3520, 18.6466);
  LatLng? myLocation;

  Future<void> _showMyLocationOnMap(BuildContext context, AppState state) async {
    final p = await _getLocationWithPrompt(context, state);
    if (p == null || !mounted) return;

    setState(() {
      myLocation = p;
      center = p;
    });
    controller.move(p, 17);
  }

  Future<void> _openAddWithGpsAndDuplicateCheck(BuildContext context, AppState state) async {
    try {
      final p = await _getLocationWithPrompt(context, state);
      if (p == null) return;
      center = p;
      controller.move(p, 16);

      final nearby = await state.findNearbySites(
        latitude: p.latitude,
        longitude: p.longitude,
        radiusMeters: 50,
      );

      if (!context.mounted) return;

      if (nearby.isNotEmpty) {
        final nearest = nearby.first;
        final decision = await showDialog<String>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Budka może już istnieć'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('W pobliżu Twojej lokalizacji są już dodane obiekty. Sprawdź, czy nie dodajesz tej samej budki drugi raz.'),
                  const SizedBox(height: 12),
                  for (final item in nearby.take(3)) _NearbySiteTile(result: item),
                ],
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, 'cancel'), child: const Text('Anuluj')),
              TextButton(onPressed: () => Navigator.pop(context, 'show'), child: const Text('Pokaż najbliższą')),
              FilledButton(onPressed: () => Navigator.pop(context, 'add'), child: const Text('Dodaj mimo to')),
            ],
          ),
        );

        if (!context.mounted) return;

        if (decision == 'show') {
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: nearest.site)));
          return;
        }

        if (decision != 'add') return;
      }

      Navigator.of(context).push(MaterialPageRoute(builder: (_) => AddSitePage(initialPoint: p)));
    } catch (e) {
      state.showError('Nie udało się pobrać GPS: $e. Możesz użyć przycisku Mapa i wskazać punkt ręcznie.');
    }
  }


  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final sites = state.visibleSites();

    return Stack(
      children: [
        FlutterMap(
          mapController: controller,
          options: MapOptions(
            initialCenter: center,
            initialZoom: 12,
            onTap: (_, point) {
              if (state.pickingOnMap) {
                state.setPicking(false);
                if (!_ensureLoggedInForChanges(context, state, 'dodawanie budki')) return;
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => AddSitePage(initialPoint: point),
                ));
              }
            },
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'pl.bartoszlawicki.ptasia_mapa_clean',
            ),
            MarkerLayer(
              markers: [
                ...sites.map((s) {
                  return Marker(
                    point: LatLng(s.latitude, s.longitude),
                    width: 54,
                    height: 54,
                    child: GestureDetector(
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: s))),
                      child: ObjectMarker(site: s),
                    ),
                  );
                }),
                if (myLocation != null)
                  Marker(
                    point: myLocation!,
                    width: 54,
                    height: 54,
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.blue.withOpacity(0.18),
                        border: Border.all(color: Colors.blue, width: 3),
                      ),
                      child: const Icon(Icons.my_location, color: Colors.blue, size: 30),
                    ),
                  ),
              ],
            ),
          ],
        ),
        Positioned(
          left: 14,
          top: 18,
          right: 14,
          child: _MapStatsBanner(sites: sites, state: state),
        ),
        if (sites.isEmpty)
          Positioned(
            left: 14,
            bottom: 18,
            right: 94,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.92),
                borderRadius: BorderRadius.circular(18),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10)],
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Text(
                  'Mapa działa. Brak widocznych obiektów — dodaj budkę z GPS albo wskaż punkt na mapie.',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ),
        Positioned(
          right: 12,
          top: 142,
          child: Column(
            children: [
              MapRoundButton(
                icon: Icons.my_location,
                label: 'GPS',
                onTap: () => _showMyLocationOnMap(context, state),
              ),
              MapRoundButton(
                icon: Icons.add_location_alt,
                label: 'Mapa',
                onTap: () {
                  if (!_ensureLoggedInForChanges(context, state, 'wskazanie miejsca i dodanie budki')) return;
                  state.setPicking(true);
                },
              ),
              MapRoundButton(
                icon: Icons.sync,
                label: state.syncing ? '...' : 'Sync',
                onTap: state.syncing ? null : () => state.sync(),
              ),
              MapRoundButton(
                icon: Icons.add,
                label: 'Dodaj',
                onTap: () {
                  if (!_ensureLoggedInForChanges(context, state, 'dodawanie budki')) return;
                  _openAddWithGpsAndDuplicateCheck(context, state);
                },
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class MapRoundButton extends StatelessWidget {
  const MapRoundButton({super.key, required this.icon, required this.label, required this.onTap});

  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        elevation: 6,
        shadowColor: Colors.black26,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: SizedBox(
            width: 66,
            height: 58,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: onTap == null ? Colors.grey : AppTheme.green, size: 22),
                Text(label, style: TextStyle(color: onTap == null ? Colors.grey : AppTheme.green, fontSize: 11, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ObjectMarker extends StatelessWidget {
  const ObjectMarker({super.key, required this.site});

  final NestSite site;

  @override
  Widget build(BuildContext context) {
    IconData icon;
    Color color;

    switch (site.type) {
      case 'Budka lęgowa':
        icon = Icons.house_rounded;
        color = const Color(0xFF7A4A20);
        break;
      case 'Dziupla naturalna':
        icon = Icons.nature_rounded;
        color = const Color(0xFF2E7D32);
        break;
      case 'Dziupla sztuczna':
        icon = Icons.account_tree_rounded;
        color = const Color(0xFF5E35B1);
        break;
      case 'Karmnik':
        icon = Icons.ramen_dining_rounded;
        color = const Color(0xFFEF6C00);
        break;
      case 'Schronienie':
        icon = Icons.roofing_rounded;
        color = const Color(0xFF3949AB);
        break;
      default:
        icon = Icons.location_on_rounded;
        color = Colors.blueGrey;
    }

    final needsRepair = _siteNeedsRepair(site);
    final cleaned = _latestCleanedInspection(site) != null;
    if (site.hiddenFromUsers) color = Colors.grey;
    if (site.deleteRequested) color = Colors.red;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            border: Border.all(color: color, width: 3),
            boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
          ),
          child: Icon(icon, color: color, size: 28),
        ),
        if (needsRepair)
          Positioned(
            right: -4,
            top: -4,
            child: Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                color: Colors.red,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: const Icon(Icons.build_rounded, color: Colors.white, size: 13),
            ),
          )
        else if (cleaned)
          Positioned(
            right: -4,
            top: -4,
            child: Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                color: AppTheme.green,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: const Icon(Icons.check, color: Colors.white, size: 13),
            ),
          ),
      ],
    );
  }
}

class _MapStatsBanner extends StatelessWidget {
  const _MapStatsBanner({required this.sites, required this.state});

  final List<NestSite> sites;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    if (state.pickingOnMap) {
      return DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xFFFFF8E1).withOpacity(0.97),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: const Color(0xFFE2C474)),
          boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 14, offset: Offset(0, 6))],
        ),
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          child: Row(
            children: [
              Icon(Icons.touch_app, color: Color(0xFFB8792A)),
              SizedBox(width: 8),
              Expanded(child: Text('Kliknij mapę, aby wybrać miejsce budki.', style: TextStyle(fontWeight: FontWeight.w900))),
            ],
          ),
        ),
      );
    }

    final birds = sites.where((s) => s.inspections.any((i) => i.birdsPresent)).length;
    final repair = sites.where((s) => s.repairNeeded).length;
    final requests = sites.where((s) => s.deleteRequested || s.reportStatus.toLowerCase().contains('zgłosz')).length;

    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0A6B35), Color(0xFF168547), Color(0xFF35A764)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 18, offset: Offset(0, 8))],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 11),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                const Icon(Icons.park, color: Colors.white, size: 19),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Tryb: ${state.roleLabel}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: _MapStatItem(icon: Icons.park, value: sites.length, label: 'Obiekty')),
                Expanded(child: _MapStatItem(icon: Icons.flutter_dash, value: birds, label: 'Ptaki')),
                Expanded(child: _MapStatItem(icon: Icons.build, value: repair, label: 'Naprawy')),
                Expanded(child: _MapStatItem(icon: Icons.notifications_none, value: requests, label: 'Zgłosz.')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MapStatItem extends StatelessWidget {
  const _MapStatItem({required this.icon, required this.value, required this.label});

  final IconData icon;
  final int value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        CircleAvatar(
          radius: 18,
          backgroundColor: Colors.white.withOpacity(0.18),
          child: Icon(icon, size: 18, color: Colors.white),
        ),
        const SizedBox(height: 4),
        Text('$value', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)),
      ],
    );
  }
}


class AddSitePage extends StatefulWidget {
  const AddSitePage({super.key, this.initialPoint, this.editSite});

  final LatLng? initialPoint;
  final NestSite? editSite;

  @override
  State<AddSitePage> createState() => _AddSitePageState();
}

class _AddSitePageState extends State<AddSitePage> {
  late final TextEditingController name;
  late final TextEditingController place;
  late final TextEditingController damage;
  late final TextEditingController notes;
  late String type;
  late String status;
  late bool repairNeeded;
  late double lat;
  late double lng;
  final MapController addMapController = MapController();
  final ImagePicker imagePicker = ImagePicker();
  final List<String> photoPaths = [];
  bool checkingNearby = false;
  List<NearbySite> nearbySites = [];

  @override
  void initState() {
    super.initState();
    final s = widget.editSite;
    name = TextEditingController(text: s?.name ?? '');
    place = TextEditingController(text: s?.placeDescription ?? '');
    damage = TextEditingController(text: s?.damageDescription ?? '');
    notes = TextEditingController(text: s?.notes ?? '');
    type = s?.type ?? 'Budka lęgowa';
    status = s?.technicalStatus ?? 'Dobry';
    repairNeeded = s?.repairNeeded ?? false;
    photoPaths.addAll(s?.photoPaths ?? const []);
    lat = s?.latitude ?? widget.initialPoint?.latitude ?? 54.3520;
    lng = s?.longitude ?? widget.initialPoint?.longitude ?? 18.6466;

    Future.microtask(_refreshNearbyCandidates);
  }

  void _setLocation(LatLng point, {bool moveMap = true}) {
    setState(() {
      lat = point.latitude;
      lng = point.longitude;
    });
    if (moveMap) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        try {
          addMapController.move(point, 17);
        } catch (_) {}
      });
    }
    Future.microtask(_refreshNearbyCandidates);
  }

  Future<void> _useGpsForForm(AppState state) async {
    try {
      final p = await _getLocationWithPrompt(context, state);
      if (p == null) return;
      _setLocation(p);
      state.showInfo('Pobrano lokalizację GPS.');
    } catch (e) {
      state.showError(e.toString());
    }
  }

  Future<void> _refreshNearbyCandidates() async {
    if (!mounted) return;
    final state = AppStateScope.of(context);
    setState(() => checkingNearby = true);
    final results = await state.findNearbySites(
      latitude: lat,
      longitude: lng,
      radiusMeters: 50,
      excludeId: widget.editSite?.id,
    );
    if (!mounted) return;
    setState(() {
      nearbySites = results;
      checkingNearby = false;
    });
  }

  Future<bool> _confirmDuplicateIfNeeded(AppState state) async {
    final results = await state.findNearbySites(
      latitude: lat,
      longitude: lng,
      radiusMeters: 50,
      excludeId: widget.editSite?.id,
    );

    if (!mounted) return false;

    setState(() => nearbySites = results);
    if (results.isEmpty) return true;

    final nearest = results.first;
    final decision = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Możliwy duplikat'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Jesteś bardzo blisko obiektu, który jest już w systemie. '
                'Sprawdź, czy nie dodajesz tej samej budki drugi raz.',
              ),
              const SizedBox(height: 12),
              _NearbySiteTile(result: nearest),
              if (results.length > 1) ...[
                const SizedBox(height: 8),
                Text('Inne bliskie obiekty: ${results.length - 1}'),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, 'cancel'),
            child: const Text('Anuluj'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, 'show'),
            child: const Text('Pokaż obiekt'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, 'save'),
            child: const Text('Dodaj mimo to'),
          ),
        ],
      ),
    );

    if (!mounted) return false;

    if (decision == 'show') {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: nearest.site)));
      return false;
    }

    return decision == 'save';
  }

  Future<void> _pickPhoto(ImageSource source) async {
    try {
      final picked = await imagePicker.pickImage(source: source, imageQuality: 82, maxWidth: 1800);
      if (picked == null) return;
      setState(() => photoPaths.add(picked.path));
    } catch (e) {
      AppStateScope.of(context).showError('Nie udało się dodać zdjęcia: $e');
    }
  }

  Future<void> _save() async {
    final state = AppStateScope.of(context);
    final canSave = await _confirmDuplicateIfNeeded(state);
    if (!canSave) return;

    if (widget.editSite == null) {
      state.createSite(
        name: name.text,
        type: type,
        latitude: lat,
        longitude: lng,
        placeDescription: place.text,
        technicalStatus: status,
        repairNeeded: repairNeeded,
        damageDescription: damage.text,
        notes: notes.text,
        photoPaths: List<String>.from(photoPaths),
      );
    } else {
      final s = widget.editSite!;
      s.name = name.text;
      s.type = type;
      s.latitude = lat;
      s.longitude = lng;
      s.placeDescription = place.text;
      s.technicalStatus = status;
      s.repairNeeded = repairNeeded;
      s.damageDescription = damage.text;
      s.notes = notes.text;
      s.photoPaths = List<String>.from(photoPaths);
      await state.updateSite(s);
    }

    if (!mounted) return;
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);

    if (!state.canCreateObjects) {
      return Scaffold(
        appBar: AppBar(title: const Text('Dodaj obiekt')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Tryb Gość', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    const Text('Gość może tylko oglądać obiekty na mapie. Dodawanie i edycja budek wymaga zalogowania.'),
                    const SizedBox(height: 14),
                    FilledButton.icon(
                      onPressed: () => _showAccountDialog(context),
                      icon: const Icon(Icons.login),
                      label: const Text('Zaloguj się'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(widget.editSite == null ? 'Dodaj obiekt' : 'Edytuj obiekt')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: [
          DropdownButtonFormField<String>(
            value: type,
            decoration: const InputDecoration(labelText: 'Typ obiektu'),
            items: objectTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => type = v ?? type),
          ),
          const SizedBox(height: 10),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Nazwa / numer')),
          const SizedBox(height: 10),
          TextField(controller: place, decoration: const InputDecoration(labelText: 'Opis miejsca')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: status,
            decoration: const InputDecoration(labelText: 'Stan techniczny'),
            items: technicalStatuses.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => status = v ?? status),
          ),
          SwitchListTile(
            value: repairNeeded,
            onChanged: (v) => setState(() => repairNeeded = v),
            title: const Text('Wymaga naprawy'),
          ),
          TextField(controller: damage, decoration: const InputDecoration(labelText: 'Opis uszkodzenia')),
          const SizedBox(height: 10),
          TextField(controller: notes, decoration: const InputDecoration(labelText: 'Notatki'), maxLines: 3),
          const SizedBox(height: 16),
          _SectionTitle('Zdjęcia budki / lokalizacji / uszkodzenia'),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      for (final path in photoPaths)
                        _PhotoThumb(
                          path: path,
                          onRemove: () => setState(() => photoPaths.remove(path)),
                        ),
                      _PhotoButton(
                        icon: Icons.photo_camera,
                        label: 'Aparat',
                        onTap: () => _pickPhoto(ImageSource.camera),
                      ),
                      _PhotoButton(
                        icon: Icons.photo_library,
                        label: 'Galeria',
                        onTap: () => _pickPhoto(ImageSource.gallery),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text('Możesz dodać zdjęcia budki, otoczenia, lokalizacji lub uszkodzenia.', style: TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          _SectionTitle('Lokalizacja budki'),
          const SizedBox(height: 8),
          Card(
            clipBehavior: Clip.antiAlias,
            child: Column(
              children: [
                SizedBox(
                  height: 230,
                  child: FlutterMap(
                    mapController: addMapController,
                    options: MapOptions(
                      initialCenter: LatLng(lat, lng),
                      initialZoom: 16,
                      onTap: (_, point) => _setLocation(point),
                    ),
                    children: [
                      TileLayer(
                        urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                        userAgentPackageName: 'pl.bartoszlawicki.ptasia_mapa_clean',
                      ),
                      MarkerLayer(
                        markers: [
                          Marker(
                            point: LatLng(lat, lng),
                            width: 62,
                            height: 62,
                            child: const Icon(Icons.location_on, color: Colors.red, size: 54, shadows: [Shadow(color: Colors.black38, blurRadius: 8)]),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                  child: Column(
                    children: [
                      Text(
                        'Lat: ${lat.toStringAsFixed(6)}, Lng: ${lng.toStringAsFixed(6)}',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: () => _useGpsForForm(state),
                              icon: const Icon(Icons.my_location),
                              label: const Text('Z GPS'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: checkingNearby ? null : _refreshNearbyCandidates,
                              icon: checkingNearby
                                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                                  : const Icon(Icons.radar),
                              label: const Text('Sprawdź'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      const Text('Możesz dotknąć mapy, aby wskazać dokładne miejsce budki.', style: TextStyle(fontSize: 12, color: Colors.black54)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (nearbySites.isNotEmpty)
            _NearbyWarningCard(
              results: nearbySites,
              onOpen: (site) {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: site)));
              },
            ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('Zapisz'),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 5, height: 22, decoration: BoxDecoration(color: AppTheme.green, borderRadius: BorderRadius.circular(12))),
        const SizedBox(width: 8),
        Text(text, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
      ],
    );
  }
}


class _PhotoButton extends StatelessWidget {
  const _PhotoButton({required this.icon, required this.label, required this.onTap});

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 86,
        height: 86,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: const Color(0xFFEFF7EA),
          border: Border.all(color: const Color(0xFFDDE8D4)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppTheme.green),
            const SizedBox(height: 5),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class _PhotoThumb extends StatelessWidget {
  const _PhotoThumb({required this.path, required this.onRemove});

  final String path;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.file(
            File(path),
            width: 86,
            height: 86,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              width: 86,
              height: 86,
              color: const Color(0xFFEFF7EA),
              child: const Icon(Icons.broken_image, color: Colors.grey),
            ),
          ),
        ),
        Positioned(
          right: -8,
          top: -8,
          child: InkWell(
            onTap: onRemove,
            child: Container(
              decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
              padding: const EdgeInsets.all(4),
              child: const Icon(Icons.close, color: Colors.white, size: 14),
            ),
          ),
        ),
      ],
    );
  }
}


class _NearbyWarningCard extends StatelessWidget {
  const _NearbyWarningCard({
    required this.results,
    required this.onOpen,
  });

  final List<NearbySite> results;
  final ValueChanged<NestSite> onOpen;

  @override
  Widget build(BuildContext context) {
    final nearest = results.first;
    return Card(
      color: Colors.orange.shade50,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.warning_amber, color: Colors.orange),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Możliwy duplikat',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text('W pobliżu jest już obiekt. Sprawdź, czy ta budka nie została wcześniej dodana.'),
            const SizedBox(height: 10),
            _NearbySiteTile(result: nearest),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: () => onOpen(nearest.site),
                icon: const Icon(Icons.visibility),
                label: const Text('Pokaż obiekt'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NearbySiteTile extends StatelessWidget {
  const _NearbySiteTile({required this.result});

  final NearbySite result;

  @override
  Widget build(BuildContext context) {
    final site = result.site;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: ObjectMarker(site: site),
      title: Text(site.name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${site.type}\nOdległość: ${result.distanceText} • Stan: ${site.technicalStatus}'),
      isThreeLine: true,
    );
  }
}

class ListPage extends StatelessWidget {
  const ListPage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final sites = state.visibleSites();

    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        const StatsPanel(),
        if (sites.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                state.loggedIn || state.isAdmin
                    ? 'Brak Twoich obiektów do wyświetlenia. Dodaj pierwszy obiekt z mapy lub GPS.'
                    : 'Brak obiektów do wyświetlenia. Możesz dodać nowy obiekt bez logowania.',
              ),
            ),
          ),
        for (final s in sites)
          Card(
            child: ListTile(
              leading: ObjectMarker(site: s),
              title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${s.type}\n${s.technicalStatus} • ${s.ownerEmail}'),
              isThreeLine: true,
              trailing: s.deleteRequested ? const Icon(Icons.report, color: Colors.red) : null,
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: s))),
            ),
          ),
      ],
    );
  }
}

class StatsPanel extends StatelessWidget {
  const StatsPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final birds = state.commonBirds();
    final latest = state.latestSites();

    return Column(
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Row(
              children: [
                const Icon(Icons.account_circle, color: AppTheme.green),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Jesteś zalogowany jako: ${state.roleLabel}',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
                if (state.loggedIn)
                  TextButton.icon(
                    onPressed: state.signOut,
                    icon: const Icon(Icons.logout),
                    label: const Text('Wyloguj'),
                  ),
              ],
            ),
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Ostatnio dodane budki / obiekty', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                if (latest.isEmpty)
                  const Text('Brak ostatnio dodanych obiektów.')
                else
                  for (final s in latest)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: ObjectMarker(site: s),
                      title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text('${s.type} • ${DateFormat('dd.MM.yyyy').format(s.createdAt)}'),
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: s))),
                    ),
              ],
            ),
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Jakich ptaków jest najwięcej', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                if (birds.isEmpty)
                  const Text('Brak wpisanych obserwacji ptaków.')
                else
                  for (final e in birds.entries.take(8))
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          const Icon(Icons.flutter_dash, color: AppTheme.green),
                          const SizedBox(width: 8),
                          Expanded(child: Text(e.key, style: const TextStyle(fontWeight: FontWeight.w700))),
                          CircleAvatar(
                            radius: 15,
                            backgroundColor: const Color(0xFFDDEFD8),
                            child: Text('${e.value}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppTheme.green)),
                          ),
                        ],
                      ),
                    ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}


class SiteDetailsPage extends StatelessWidget {
  const SiteDetailsPage({super.key, required this.site});

  final NestSite site;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final canEdit = state.canEdit(site);

    return Scaffold(
      appBar: AppBar(title: Text(site.name)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 28),
        children: [
          Card(
            child: ListTile(
              leading: ObjectMarker(site: site),
              title: Text(site.type),
              subtitle: Text('Lat ${site.latitude.toStringAsFixed(5)}, Lng ${site.longitude.toStringAsFixed(5)}\nStatus: ${site.technicalStatus}'),
              isThreeLine: true,
              trailing: IconButton(
                tooltip: 'Nawiguj',
                icon: const Icon(Icons.navigation),
                onPressed: () => _openGoogleMapsTo(site),
              ),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Opis: ${site.placeDescription.isEmpty ? '—' : site.placeDescription}'),
                  Text('Uszkodzenie: ${site.damageDescription.isEmpty ? '—' : site.damageDescription}'),
                  Text('Notatki: ${site.notes.isEmpty ? '—' : site.notes}'),
                  Text('Właściciel: ${site.ownerEmail}'),
                  if (site.hiddenFromUsers) const Text('Ukryty dla użytkowników', style: TextStyle(color: Colors.grey)),
                  if (site.deleteRequested) Text('Prośba o usunięcie: ${site.deleteReason}', style: const TextStyle(color: Colors.red)),
                ],
              ),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Zdjęcia obiektu', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                  const SizedBox(height: 10),
                  if (site.photoPaths.isEmpty)
                    const Text('Brak zdjęć.')
                  else
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        for (final p in site.photoPaths)
                          ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Image.file(
                              File(p),
                              width: 96,
                              height: 96,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                width: 96,
                                height: 96,
                                color: const Color(0xFFEFF7EA),
                                child: const Icon(Icons.broken_image),
                              ),
                            ),
                          ),
                      ],
                    ),
                  if (canEdit) ...[
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        FilledButton.icon(
                          onPressed: () => _addPhotoToExistingSite(context, site, ImageSource.camera),
                          icon: const Icon(Icons.photo_camera),
                          label: const Text('Dodaj z aparatu'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => _addPhotoToExistingSite(context, site, ImageSource.gallery),
                          icon: const Icon(Icons.photo_library),
                          label: const Text('Dodaj z galerii'),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),

          if (canEdit)
            Wrap(
              spacing: 10,
              runSpacing: 8,
              children: [
                FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AddSitePage(editSite: site))),
                  icon: const Icon(Icons.edit),
                  label: const Text('Edytuj'),
                ),
                FilledButton.icon(
                  onPressed: () async {
                    await state.deleteSite(site);
                    if (!context.mounted) return;
                    Navigator.of(context).pop();
                  },
                  icon: const Icon(Icons.delete),
                  label: const Text('Usuń'),
                ),
                if (state.isAdmin)
                  FilledButton.icon(
                    onPressed: () async {
                      site.hiddenFromUsers = !site.hiddenFromUsers;
                      await state.updateSite(site);
                    },
                    icon: Icon(site.hiddenFromUsers ? Icons.visibility : Icons.visibility_off),
                    label: Text(site.hiddenFromUsers ? 'Pokaż użytkownikom' : 'Ukryj'),
                  ),
              ],
            )
          else if (state.loggedIn)
            FilledButton.icon(
              onPressed: () => _showDeleteRequestDialog(context, site),
              icon: const Icon(Icons.report),
              label: const Text('Zgłoś prośbę o usunięcie'),
            )
          else
            const Card(
              child: Padding(
                padding: EdgeInsets.all(14),
                child: Text('Tryb Gość: możesz oglądać obiekt, ale dodawanie, edycja, zdjęcia i kontrole wymagają logowania.'),
              ),
            ),
          const SizedBox(height: 16),
          if (state.canAddInspections)
            FilledButton.icon(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AddInspectionPage(site: site))),
              icon: const Icon(Icons.fact_check),
              label: const Text('Dodaj kontrolę'),
            ),
          const SizedBox(height: 12),
          const Text('Kontrole i stwierdzenia ptaków', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          for (final i in site.inspections)
            Card(
              child: ListTile(
                leading: Icon(i.birdsPresent ? Icons.flutter_dash : Icons.check_circle_outline),
                title: Text(DateFormat('dd.MM.yyyy').format(i.date)),
                subtitle: Text(
                  'Kontrolujący: ${i.inspector.isEmpty ? '—' : i.inspector}\n'
                  'Czyszczona: ${i.cleaned ? 'tak' : 'nie'}'
                  '${i.birdsPresent ? '\nPtaki: ${i.birdSpecies}, jaja ${i.eggsCount}, pisklęta ${i.chicksCount}, dorosłe ${i.adultsCount}' : '\nPtaki: nie'}'
                  '${i.notes.isNotEmpty ? '\n${i.notes}' : ''}',
                ),
                isThreeLine: true,
              ),
            ),
        ],
      ),
    );
  }
}

class AddInspectionPage extends StatefulWidget {
  const AddInspectionPage({super.key, required this.site});

  final NestSite site;

  @override
  State<AddInspectionPage> createState() => _AddInspectionPageState();
}

class _AddInspectionPageState extends State<AddInspectionPage> {
  final inspector = TextEditingController();
  final cleanedBy = TextEditingController();
  final notes = TextEditingController();
  final eggs = TextEditingController(text: '0');
  final chicks = TextEditingController(text: '0');
  final adults = TextEditingController(text: '0');

  DateTime date = DateTime.now();
  bool cleaned = false;
  bool birds = false;
  String species = birdSpecies.first;
  String condition = 'Dobry';

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);

    if (!state.canAddInspections) {
      return Scaffold(
        appBar: AppBar(title: const Text('Dodaj kontrolę')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Wymagane logowanie', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    const Text('Gość może oglądać obiekty na mapie, ale dodawanie kontroli i czyszczenia wymaga logowania.'),
                    const SizedBox(height: 14),
                    FilledButton.icon(
                      onPressed: () => _showAccountDialog(context),
                      icon: const Icon(Icons.login),
                      label: const Text('Zaloguj się'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Dodaj kontrolę')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            title: Text(DateFormat('dd.MM.yyyy').format(date)),
            subtitle: const Text('Data kontroli'),
            trailing: const Icon(Icons.calendar_month),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                firstDate: DateTime(2020),
                lastDate: DateTime(2100),
                initialDate: date,
              );
              if (picked != null) setState(() => date = picked);
            },
          ),
          TextField(controller: inspector, decoration: const InputDecoration(labelText: 'Kontrolujący')),
          Card(
            color: _isCleaningPeriod(DateTime.now()) ? const Color(0xFFE8F5E9) : const Color(0xFFFFF8E1),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                _cleaningCounterText(DateTime.now()),
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
          ),
          SwitchListTile(
            value: cleaned,
            onChanged: (v) => setState(() => cleaned = v),
            title: const Text('Budka czyszczona'),
            subtitle: const Text('Czyszczenie wpisuj tylko wtedy, gdy faktycznie zostało wykonane.'),
          ),
          if (cleaned) TextField(controller: cleanedBy, decoration: const InputDecoration(labelText: 'Kto czyścił')),
          DropdownButtonFormField<String>(
            value: condition,
            decoration: const InputDecoration(labelText: 'Stan'),
            items: technicalStatuses.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => condition = v ?? condition),
          ),
          SwitchListTile(
            value: birds,
            onChanged: (v) => setState(() => birds = v),
            title: const Text('Czy są ptaki?'),
          ),
          if (birds) ...[
            Autocomplete<String>(
              initialValue: TextEditingValue(text: species),
              optionsBuilder: (value) {
                final q = value.text.toLowerCase();
                return birdSpecies.where((s) => s.toLowerCase().contains(q)).take(25);
              },
              onSelected: (v) => species = v,
              fieldViewBuilder: (context, controller, focusNode, onSubmit) {
                controller.text = species;
                return TextField(
                  controller: controller,
                  focusNode: focusNode,
                  decoration: const InputDecoration(labelText: 'Gatunek ptaka'),
                  onChanged: (v) => species = v,
                );
              },
            ),
            Row(
              children: [
                Expanded(child: TextField(controller: eggs, decoration: const InputDecoration(labelText: 'Jaja'), keyboardType: TextInputType.number)),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: chicks, decoration: const InputDecoration(labelText: 'Pisklęta'), keyboardType: TextInputType.number)),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: adults, decoration: const InputDecoration(labelText: 'Dorosłe'), keyboardType: TextInputType.number)),
              ],
            ),
          ],
          TextField(controller: notes, decoration: const InputDecoration(labelText: 'Notatki'), maxLines: 3),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () async {
              widget.site.inspections.add(Inspection(
                id: const Uuid().v4(),
                date: date,
                inspector: inspector.text,
                cleaned: cleaned,
                cleanedBy: cleanedBy.text,
                condition: condition,
                birdsPresent: birds,
                birdSpecies: birds ? species : '',
                eggsCount: int.tryParse(eggs.text) ?? 0,
                chicksCount: int.tryParse(chicks.text) ?? 0,
                adultsCount: int.tryParse(adults.text) ?? 0,
                notes: notes.text,
                locallyChanged: true,
              ));
              await state.updateSite(widget.site);
              if (!context.mounted) return;
              Navigator.of(context).pop();
            },
            icon: const Icon(Icons.save),
            label: const Text('Zapisz kontrolę'),
          ),
        ],
      ),
    );
  }
}

class NearbyPage extends StatefulWidget {
  const NearbyPage({super.key});

  @override
  State<NearbyPage> createState() => _NearbyPageState();
}

class _NearbyPageState extends State<NearbyPage> {
  final distances = const [10, 30, 50, 100, 250, 500];
  int radiusMeters = 50;
  LatLng? current;
  bool loading = false;
  String? error;
  bool autoStartedNearby = false;

  Future<void> _refresh(AppState state) async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      if (!state.syncing) {
        await state.sync(silent: true);
      }

      if (!mounted) return;
      final p = await _getLocationWithPrompt(context, state);
      if (p != null && mounted) {
        setState(() => current = p);
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  List<NearbySite> _nearby(AppState state) {
    final p = current;
    if (p == null) return <NearbySite>[];

    final distance = const Distance();
    final result = <NearbySite>[];

    for (final site in state.visibleSites()) {
      if (site.deleted || site.hiddenFromUsers) continue;
      final meters = distance.as(LengthUnit.Meter, p, LatLng(site.latitude, site.longitude));
      if (meters <= radiusMeters) {
        result.add(NearbySite(site: site, distanceMeters: meters));
      }
    }

    result.sort((a, b) => a.distanceMeters.compareTo(b.distanceMeters));
    return result;
  }


  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!autoStartedNearby) {
      autoStartedNearby = true;
      Future.microtask(() => _refresh(AppStateScope.of(context)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final items = _nearby(state);

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Budki w pobliżu', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                const Text('Wybierz promień i pobierz GPS. Lista pokaże najbliższe budki z odległością od Ciebie.'),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final d in distances)
                      ChoiceChip(
                        label: Text('$d m'),
                        selected: radiusMeters == d,
                        onSelected: (_) => setState(() => radiusMeters = d),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: loading ? null : () => _refresh(state),
                    icon: loading
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.my_location),
                    label: Text(loading ? 'Pobieram GPS...' : 'Pobierz GPS i pokaż budki'),
                  ),
                ),
                if (current != null) ...[
                  const SizedBox(height: 8),
                  Text('Twoja pozycja: ${current!.latitude.toStringAsFixed(6)}, ${current!.longitude.toStringAsFixed(6)}'),
                ],
                if (error != null) ...[
                  const SizedBox(height: 8),
                  Text(error!, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w800)),
                ],
              ],
            ),
          ),
        ),
        if (current == null)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text('Kliknij GPS, żeby pokazać budki w pobliżu.'),
            ),
          )
        else if (items.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Text('Brak budek w promieniu $radiusMeters m.'),
            ),
          )
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text('Znaleziono: ${items.length}', style: const TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
        for (final item in items)
          Card(
            child: ListTile(
              leading: ObjectMarker(site: item.site),
              title: Text(item.site.name, style: const TextStyle(fontWeight: FontWeight.w900)),
              subtitle: Text('${item.site.type}\nOdległość: ${item.distanceText} • Stan: ${item.site.technicalStatus}'),
              isThreeLine: true,
              trailing: IconButton(
                tooltip: 'Nawiguj',
                icon: const Icon(Icons.navigation),
                onPressed: () => _openGoogleMapsTo(item.site),
              ),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: item.site))),
            ),
          ),
      ],
    );
  }
}


class RepairPage extends StatelessWidget {
  const RepairPage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final repairs = state.repairSites();

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
      children: [
        Card(
          color: const Color(0xFFFFF3E0),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                const Icon(Icons.build_circle, color: Colors.red, size: 34),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Budki / obiekty zgłoszone do naprawy: ${repairs.length}',
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (repairs.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text('Brak obiektów oznaczonych jako uszkodzone lub wymagające naprawy.'),
            ),
          ),
        for (final s in repairs)
          Card(
            child: ListTile(
              leading: ObjectMarker(site: s),
              title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w900)),
              subtitle: Text([
                s.type,
                'Stan: ${s.technicalStatus}',
                if (s.damageDescription.trim().isNotEmpty) 'Opis: ${s.damageDescription}',
                if (s.notes.trim().isNotEmpty) 'Notatki: ${s.notes}',
                'Aktualizacja: ${DateFormat('dd.MM.yyyy').format(s.updatedAt)}',
              ].join('\n')),
              isThreeLine: true,
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: s))),
            ),
          ),
      ],
    );
  }
}

class CleaningPage extends StatelessWidget {
  const CleaningPage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final now = DateTime.now();
    final inPeriod = _isCleaningPeriod(now);
    final start = _cleaningSeasonStart(now);
    final endVisible = _cleaningSeasonEndExclusive(start).subtract(const Duration(days: 1));
    final toClean = state.toCleanSites();
    final cleaned = state.cleanedSites();
    final format = DateFormat('dd.MM.yyyy');

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
      children: [
        Card(
          color: inPeriod ? const Color(0xFFE8F5E9) : const Color(0xFFFFF8E1),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(inPeriod ? Icons.cleaning_services : Icons.event, color: AppTheme.green, size: 36),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '${_cleaningCounterText(now)}\nOkres czyszczenia: 16.10 – koniec lutego.',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                const Icon(Icons.calendar_month, color: AppTheme.green),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Aktualny sezon: ${format.format(start)} – ${format.format(endVisible)}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (!state.loggedIn && !state.isAdmin)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('Tryb Gość: listę można oglądać, ale wpisanie czyszczenia wymaga logowania.'),
            ),
          ),
        _CleaningSectionHeader(
          title: 'Do wyczyszczenia',
          count: toClean.length,
          icon: Icons.cleaning_services,
        ),
        if (toClean.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text('Wszystkie widoczne budki mają wpisane czyszczenie w tym sezonie.'),
            ),
          )
        else
          for (final s in toClean)
            _CleaningSiteCard(
              site: s,
              subtitle: [
                s.type,
                if (_latestCleanedInspection(s) != null) 'Ostatnio czyszczona: ${format.format(_latestCleanedInspection(s)!.date)}',
                if (_latestCleanedInspection(s) == null) 'Brak wpisu o czyszczeniu',
              ].join('\n'),
              actionLabel: state.canAddInspections ? 'Wpisz czyszczenie' : 'Tylko podgląd',
              actionIcon: state.canAddInspections ? Icons.edit_note : Icons.visibility,
              onAction: state.canAddInspections
                  ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AddInspectionPage(site: s)))
                  : () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: s))),
            ),
        const SizedBox(height: 10),
        _CleaningSectionHeader(
          title: 'Wyczyszczone',
          count: cleaned.length,
          icon: Icons.check_circle,
        ),
        if (cleaned.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text('Brak wpisów o czyszczeniu.'),
            ),
          )
        else
          for (final s in cleaned)
            _CleaningSiteCard(
              site: s,
              subtitle: 'Czyszczona: ${format.format(_latestCleanedInspection(s)!.date)}'
                  '${_latestCleanedInspection(s)!.cleanedBy.trim().isNotEmpty ? '\nPrzez: ${_latestCleanedInspection(s)!.cleanedBy}' : ''}',
              actionLabel: 'Szczegóły',
              actionIcon: Icons.chevron_right,
              onAction: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: s))),
            ),
      ],
    );
  }
}


class _CleaningSectionHeader extends StatelessWidget {
  const _CleaningSectionHeader({
    required this.title,
    required this.count,
    required this.icon,
  });

  final String title;
  final int count;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.green),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '$title: $count',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CleaningSiteCard extends StatelessWidget {
  const _CleaningSiteCard({
    required this.site,
    required this.subtitle,
    required this.actionLabel,
    required this.actionIcon,
    required this.onAction,
  });

  final NestSite site;
  final String subtitle;
  final String actionLabel;
  final IconData actionIcon;
  final VoidCallback onAction;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteDetailsPage(site: site))),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(width: 48, height: 48, child: ObjectMarker(site: site)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(site.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                        const SizedBox(height: 4),
                        Text(subtitle, style: const TextStyle(height: 1.25)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: onAction,
                icon: Icon(actionIcon),
                label: Text(actionLabel),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  String exportText = '';
  final importController = TextEditingController();
  final emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton(onPressed: () => setState(() => exportText = state.exportCsv()), child: const Text('CSV')),
                FilledButton(onPressed: () => setState(() => exportText = state.exportKml()), child: const Text('KML')),
                FilledButton(onPressed: () => setState(() => exportText = state.exportGpx()), child: const Text('GPX')),
                FilledButton.icon(
                  onPressed: exportText.isEmpty ? null : () => Clipboard.setData(ClipboardData(text: exportText)),
                  icon: const Icon(Icons.copy),
                  label: const Text('Kopiuj'),
                ),
              ],
            ),
          ),
        ),
        if (exportText.isNotEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: SelectableText(exportText, maxLines: 12),
            ),
          ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                TextField(
                  controller: importController,
                  maxLines: 6,
                  decoration: const InputDecoration(labelText: 'Wklej GPX/KML do importu'),
                ),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: () => state.importSimpleGpxKml(importController.text),
                  icon: const Icon(Icons.upload),
                  label: const Text('Importuj'),
                ),
              ],
            ),
          ),
        ),
        if (state.isSuperAdmin)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  const Text('Nadawanie uprawnień administratora', style: TextStyle(fontWeight: FontWeight.bold)),
                  TextField(controller: emailController, decoration: const InputDecoration(labelText: 'Email użytkownika')),
                  const SizedBox(height: 10),
                  FilledButton(
                    onPressed: () => state.grantAdmin(emailController.text),
                    child: const Text('Nadaj admina'),
                  ),
                ],
              ),
            ),
          ),

        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('Obserwacje ptaków i gatunki wrażliwe', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Tu ustawiasz, jakie gatunki ukrywają dokładną lokalizację i kto może ją widzieć.'),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const BirdSensitiveAdminPage()),
                  ),
                  icon: const Icon(Icons.visibility_off),
                  label: const Text('Zarządzaj ptakami wrażliwymi'),
                ),
              ],
            ),
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Prośby o usunięcie', style: TextStyle(fontWeight: FontWeight.bold)),
                for (final s in state.sites.where((s) => s.deleteRequested && !s.deleted))
                  ListTile(
                    title: Text(s.name),
                    subtitle: Text(s.deleteReason),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => state.deleteSite(s),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

void _showDeleteRequestDialog(BuildContext context, NestSite site) {
  final controller = TextEditingController();
  final state = AppStateScope.of(context);
  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Prośba o usunięcie'),
      content: TextField(
        controller: controller,
        decoration: const InputDecoration(labelText: 'Dlaczego obiekt ma być usunięty?'),
        maxLines: 4,
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Anuluj')),
        FilledButton(
          onPressed: () async {
            await state.requestDelete(site, controller.text);
            if (context.mounted) Navigator.pop(context);
          },
          child: const Text('Wyślij'),
        ),
      ],
    ),
  );
}

void _showInfoDialog(BuildContext context) {
  showAboutDialog(
    context: context,
    applicationName: 'Ptasia Mapa',
    applicationVersion: appVersionName,
    children: const [
      Text('© Bartosz Ławicki. Wszystkie prawa zastrzeżone.'),
      SizedBox(height: 8),
      Text('Kontakt: bartoszlawicki@gmail.com'),
    ],
  );
}

void _showUpdateDialog(BuildContext context, UpdateInfo info) {
  final state = AppStateScope.of(context);
  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Dostępna aktualizacja'),
      content: SingleChildScrollView(
        child: Text(
          'Nowa wersja: ${info.versionName} (${info.versionCode})\n'
          'Obecna wersja: $appVersionName ($appVersionCode)\n\n'
          '${info.notes.isEmpty ? 'Kliknij Pobierz, aby otworzyć GitHub Release z plikiem APK.' : info.notes}\n\n'
          'Po pobraniu Android poprosi o potwierdzenie instalacji aktualizacji.',
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Później')),
        FilledButton.icon(
          onPressed: () {
            Navigator.pop(context);
            state.openUpdateDownload();
          },
          icon: const Icon(Icons.download),
          label: const Text('Pobierz'),
        ),
      ],
    ),
  );
}

void _showAdminPasswordDialog(BuildContext context) {
  final controller = TextEditingController();
  final state = AppStateScope.of(context);
  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Hasło administratora'),
      content: TextField(
        controller: controller,
        obscureText: true,
        decoration: const InputDecoration(labelText: 'Hasło'),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Anuluj')),
        FilledButton(
          onPressed: () {
            state.enableAdminWithPassword(controller.text);
            Navigator.pop(context);
          },
          child: const Text('Włącz'),
        ),
      ],
    ),
  );
}

void _showAccountDialog(BuildContext context) {
  final state = AppStateScope.of(context);
  final email = TextEditingController(text: state.currentUser?.email ?? '');
  final pass = TextEditingController();
  bool rodo = false;
  bool technicalContact = false;
  bool registerMode = false;
  bool hidePassword = true;
  bool busy = false;

  showDialog(
    context: context,
    builder: (_) => StatefulBuilder(
      builder: (context, setState) {
        if (state.loggedIn) {
          return AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Text('Konto'),
            content: Text('Zalogowano jako:\n${state.currentUser?.email}\nRola: ${state.userRole}'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Zamknij')),
              FilledButton.icon(
                onPressed: () async {
                  await state.signOut();
                  if (context.mounted) Navigator.pop(context);
                },
                icon: const Icon(Icons.logout),
                label: const Text('Wyloguj się'),
              ),
            ],
          );
        }

        final media = MediaQuery.of(context);
        final keyboard = media.viewInsets.bottom;
        final maxHeight = (media.size.height - keyboard - 48).clamp(320.0, 720.0).toDouble();

        Future<void> runAuth(Future<void> Function() action, {bool closeWhenLoggedIn = true}) async {
          if (busy) return;
          setState(() => busy = true);
          await action();
          if (context.mounted) {
            setState(() => busy = false);
            if (closeWhenLoggedIn && state.loggedIn) {
              Navigator.pop(context);
            }
          }
        }

        return Dialog(
          insetPadding: EdgeInsets.fromLTRB(14, 18, 14, keyboard > 0 ? 12 : 18),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
          backgroundColor: const Color(0xFFF4F8F1),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: maxHeight, maxWidth: 540),
            child: SingleChildScrollView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
              child: AutofillGroup(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.account_circle, color: AppTheme.green, size: 34),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Logowanie / rejestracja',
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.w900,
                                  color: const Color(0xFF132015),
                                ),
                          ),
                        ),
                        IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close, size: 30)),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _AuthSegmentButton(
                            label: 'Zaloguj',
                            selected: !registerMode,
                            onTap: () => setState(() => registerMode = false),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _AuthSegmentButton(
                            label: 'Rejestruj',
                            selected: registerMode,
                            onTap: () => setState(() => registerMode = true),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: email,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      autofillHints: const [AutofillHints.email],
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email_outlined),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: pass,
                      obscureText: hidePassword,
                      autofillHints: const [AutofillHints.password],
                      decoration: InputDecoration(
                        labelText: 'Hasło',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => hidePassword = !hidePassword),
                          icon: Icon(hidePassword ? Icons.visibility_off : Icons.visibility),
                        ),
                      ),
                    ),
                    if (registerMode) ...[
                      const SizedBox(height: 10),
                      DecoratedBox(
                        decoration: BoxDecoration(
                          color: const Color(0xFFEFF7EA),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: const Color(0xFFDDE8D4)),
                        ),
                        child: Column(
                          children: [
                            CheckboxListTile(
                              dense: true,
                              value: rodo,
                              onChanged: (v) => setState(() => rodo = v ?? false),
                              controlAffinity: ListTileControlAffinity.leading,
                              title: const Text(
                                'Akceptuję przetwarzanie danych w celu obsługi konta i zgłoszeń.',
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
                              ),
                            ),
                            CheckboxListTile(
                              dense: true,
                              value: technicalContact,
                              onChanged: (v) => setState(() => technicalContact = v ?? false),
                              controlAffinity: ListTileControlAffinity.leading,
                              title: const Text(
                                'Zgoda dobrowolna: kontakt techniczny w sprawie aplikacji.',
                                style: TextStyle(fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (!rodo)
                        const Padding(
                          padding: EdgeInsets.only(top: 8),
                          child: Text(
                            'Do rejestracji wymagana jest pierwsza zgoda.',
                            style: TextStyle(fontSize: 12, color: Colors.black54),
                          ),
                        ),
                    ] else ...[
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: busy
                              ? null
                              : () => runAuth(
                                    () => state.sendPasswordReset(email.text),
                                    closeWhenLoggedIn: false,
                                  ),
                          child: const Text('Nie pamiętasz hasła?'),
                        ),
                      ),
                    ],
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: busy
                            ? null
                            : () {
                                if (registerMode && !rodo) {
                                  state.showError('Do rejestracji wymagana jest pierwsza zgoda.');
                                  return;
                                }
                                runAuth(
                                  () => registerMode
                                      ? state.register(email.text, pass.text)
                                      : state.signIn(email.text, pass.text),
                                );
                              },
                        icon: busy
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : Icon(registerMode ? Icons.person_add_alt_1 : Icons.login),
                        label: Text(registerMode ? 'Zarejestruj' : 'Zaloguj'),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(child: Divider(color: Colors.grey.shade400)),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Text('albo'),
                        ),
                        Expanded(child: Divider(color: Colors.grey.shade400)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: busy
                            ? null
                            : () => runAuth(
                                  () => state.signInWithGoogle(),
                                  closeWhenLoggedIn: false,
                                ),
                        icon: const Icon(Icons.g_mobiledata, size: 34),
                        label: const Text('Kontynuuj z Google'),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: busy ? null : () => setState(() => registerMode = !registerMode),
                      child: Text(registerMode ? 'Masz już konto? Zaloguj się' : 'Nie masz konta? Zarejestruj się'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    ),
  );
}

class _AuthSegmentButton extends StatelessWidget {
  const _AuthSegmentButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 56,
      child: OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          backgroundColor: selected ? Colors.white : const Color(0xFFD9DED6),
          foregroundColor: selected ? AppTheme.green : Colors.grey.shade600,
          side: BorderSide(
            color: selected ? const Color(0xFFB6DEB7) : Colors.transparent,
            width: 1.5,
          ),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
        ),
        child: Text(label),
      ),
    );
  }
}

class PasswordResetPage extends StatefulWidget {
  const PasswordResetPage({super.key});

  @override
  State<PasswordResetPage> createState() => _PasswordResetPageState();
}

class _PasswordResetPageState extends State<PasswordResetPage> {
  final password = TextEditingController();
  bool hidePassword = true;
  bool busy = false;

  @override
  void dispose() {
    password.dispose();
    super.dispose();
  }

  Future<void> save() async {
    final pass = password.text.trim();
    if (pass.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hasło powinno mieć minimum 6 znaków.')),
      );
      return;
    }

    setState(() => busy = true);
    try {
      await Supabase.instance.client.auth.updateUser(
        UserAttributes(password: pass),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hasło zostało zmienione.')),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Nie udało się zmienić hasła: $e')),
      );
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nowe hasło')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Wpisz nowe hasło do konta Ptasiej Mapy.'),
            const SizedBox(height: 16),
            TextField(
              controller: password,
              obscureText: hidePassword,
              decoration: InputDecoration(
                labelText: 'Nowe hasło',
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(
                  onPressed: () => setState(() => hidePassword = !hidePassword),
                  icon: Icon(hidePassword ? Icons.visibility_off : Icons.visibility),
                ),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: busy ? null : save,
              icon: busy
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.save),
              label: const Text('Zapisz nowe hasło'),
            ),
          ],
        ),
      ),
    );
  }
}
