
# Ptasia Mapa Clean Rewrite v1

To jest czysta wersja aplikacji napisana od nowa, bez łatania poprzednich paczek.

## Funkcje

- jedna aplikacja,
- tryb gość / użytkownik / administrator,
- przejście do admina przez hasło,
- logowanie email/hasło przez Supabase,
- opcjonalne Google OAuth przez Supabase,
- gość może dodać obiekt, ale nie pobiera cudzych obiektów,
- zalogowany użytkownik widzi swoje obiekty,
- administrator widzi wszystko,
- użytkownik i administrator mogą edytować/usuwać swoje obiekty,
- prośba o usunięcie,
- mapa OpenStreetMap,
- GPS,
- kontrole i stwierdzenia ptaków,
- dłuższa lista ptaków lęgowych,
- eksport CSV/KML/GPX w adminie,
- import GPX/KML przez wklejenie tekstu,
- brak file_picker,
- brak zdjęć ptaków i opisów ptaków.

## Supabase

Uruchom `supabase/schema.sql` w SQL Editor.

## GitHub Secrets

- SUPABASE_URL
- SUPABASE_ANON_KEY
- ADMIN_PASSWORD
- SUPER_ADMIN_EMAIL



## Rejestracja bez potwierdzania emaila

Aplikacja nie pokazuje już komunikatu o potwierdzaniu emaila i po rejestracji próbuje od razu zalogować użytkownika.

Żeby Supabase faktycznie nie wymagał potwierdzenia emaila, ustaw w panelu Supabase:

Authentication → Providers → Email → Confirm email = OFF

## Nadawca emaili

Nadawcy emaili Supabase nie da się ustawić z poziomu aplikacji Flutter. Trzeba ustawić Custom SMTP w Supabase.

Ustaw:

- Sender email: bartoszlawicki@gmail.com
- Sender name: Ptasia Mapa

Ścieżka w Supabase:

Authentication → Emails / Email Templates → SMTP Settings → Enable Custom SMTP

Jeśli używasz Gmaila jako SMTP, konto zwykle musi mieć włączone 2FA i hasło aplikacji.


## Zmiany 1.2.0

- dodano łacińskie nazwy ptaków w liście gatunków,
- po zalogowaniu pusty widok nie pokazuje już komunikatu dla gościa,
- zmieniono ikonę dziupli sztucznej,
- dodano czytelny komunikat, gdy Google OAuth nie jest włączony w Supabase.

## Zmiany v1.2

- Dodano łacińskie nazwy ptaków.
- Po zalogowaniu nie pokazuje się komunikat o koncie gościa.
- Zmieniono ikonę dziupli sztucznej.

## Aktualizacje programu

Dodano przycisk sprawdzania aktualizacji i automatyczne sprawdzenie przy starcie aplikacji. Szczegóły są w `README_UPDATE.md`.

## Aktualizacje przez GitHub Releases

Dodano automatyczne wydawanie nowych wersji przez GitHub Releases. Szczegóły w `README_RELEASES.md`.

## Wersja

Ustawiono wersję aplikacji na `0.1.0+10`. W aplikacji będzie widoczne jako `0.1.0`, a Release na GitHubie jako `v0.1.0`.

## Zmiany v0.2.0

- Dodano sprawdzanie możliwych duplikatów przy dodawaniu i edycji obiektu.
- Aplikacja ostrzega, jeśli w promieniu około 35 m jest już budka/obiekt w systemie.
- Można podejrzeć znaleziony obiekt albo dodać mimo ostrzeżenia.

## Zmiany v0.2.1

- Poprawiono generowanie `AndroidManifest.xml`.
- Uprawnienia Android są teraz dodawane wewnątrz znacznika `<manifest>`, a nie przed nim.
- To naprawia błąd: `Error parsing LocalFile AndroidManifest.xml`.

## Zmiany v0.3.0

- Przywrócono wygląd bliższy v21: leśny gradient, zaokrąglone karty, baner Ptasia Strefa z logo, bardziej naturalny pasek dolny i przyciski mapy.
- Nie ma paska informującego o koncie gościa po zalogowaniu.
- Poprawiono obsługę błędu 404 przy aktualizacji. Jeśli `latest.json` jeszcze nie istnieje, aplikacja pokazuje zrozumiały komunikat.

## Zmiany v0.3.1

- Wygląd mapy bardziej jak starsza wersja: duży zielony panel statystyk.
- Usunięto fałszywą informację o nowszej wersji przy braku `latest.json`.
- Workflow nie przekazuje już automatycznie aktualnego APK jako rzekomej aktualizacji.
- Okno logowania/rejestracji jest krótsze, zgody są widoczne na telefonie, a błąd synchronizacji nie jest pokazywany jako błąd rejestracji.

## Zmiany v0.3.2

- Poprawiono błąd `The getter birdsPresent isn't defined for the type NestSite`.
- Licznik „Ptaki” w zielonym panelu liczy teraz obiekty, które mają przynajmniej jedną kontrolę z ptakami.
- Krok analizy kodu nie blokuje już builda na samych ostrzeżeniach.

## Zmiany v0.4.0

- Poprawiono wygląd ekranu mapy i zielonego panelu statystyk.
- Panel jest szerszy i dopasowany do napisów.
- Dodano widoczny tryb konta: Gość / Użytkownik / Administrator.
- Dodano opcję wylogowania z konta.
- Przy dodawaniu obiektu dodano mapkę, wybór punktu dotknięciem oraz pobranie pozycji z GPS.
- Dodano sekcje: Ostatnio dodane budki / obiekty oraz Jakich ptaków jest najwięcej.
- Błąd 404 aktualizacji jest komunikatem informacyjnym, a nie czerwonym błędem.


## Zmiany v0.5.0

- Dodano odpowiedniejsze ikony dla typów: budka, dziupla naturalna, dziupla sztuczna, karmnik, schronienie.
- Obiekty uszkodzone lub wymagające naprawy mają czerwony znacznik z kluczem.
- Dodano zakładkę `Naprawy` z listą budek/obiektów zgłoszonych do naprawy.
- Dodano zakładkę `Czyszczenie`:
  - lista budek wyczyszczonych,
  - lista budek do wyczyszczenia,
  - informacja kiedy budka była czyszczona,
  - licznik dni do rozpoczęcia okresu czyszczenia albo do jego końca.
- Okres czyszczenia liczony jest od 16 października do końca lutego.
- Dodano zdjęcia budek, lokalizacji i uszkodzeń z aparatu lub galerii.
- Dodano ikonę aplikacji jako dziuplę w drzewie.

## Zmiany v0.5.1

- Poprawiono błąd budowania APK: brakujące funkcje `_isCleaningPeriod`, `_cleaningCounterText`, `_latestCleanedInspection` i powiązane.
- Ikona drzewa/dziupli używa bezpiecznej ikony Material `park`.

## Zmiany v0.5.2

- Poprawiono brakujące `_AppTitle` / `_RoleChip`.
- Upewniono się, że funkcje czyszczenia są w `main.dart`.
- Wersja naprawia build po zmianach v0.5.

## Zmiany v0.5.3

- Poprawiono mechanizm aktualizacji: aplikacja korzysta z `latest.json` wrzucanego jako asset do GitHub Release.
- Workflow nadal próbuje zapisać `update/latest.json` w repo, ale głównym źródłem aktualizacji jest Release asset.
- Po ręcznym sprawdzeniu aktualizacji, gdy `latest.json` nie jest dostępny, aplikacja otworzy stronę pobierania zamiast udawać nową wersję.
- Gość i zwykły użytkownik widzą mapę oraz wszystkie nieukryte obiekty; edycja nadal jest tylko dla właściciela albo administratora.

## Zmiany v0.5.5

- Poprawiono kod synchronizacji.
- Aplikacja robi cichą synchronizację na starcie, jeśli Supabase jest skonfigurowany.
- Gość pobiera z Supabase wszystkie nieukryte obiekty.
- Edycja nadal jest tylko dla właściciela albo administratora.
- Zapis do Supabase jest odporny na brak kolumny `photo_urls`.
- Poprawiono komunikaty błędów Supabase.

## Zmiany v0.5.6

- Dodano zakładkę `Blisko` / `Budki w pobliżu`.
- Można wybrać promień: 10, 30, 50, 100, 250 albo 500 m.
- Lista pokazuje odległość od aktualnej pozycji GPS.
- Dodano przycisk nawigacji do Google Maps.
- Po kliknięciu `Dodaj` aplikacja pobiera GPS i sprawdza, czy w promieniu 50 m nie ma już budki.
- Przy zapisie formularza nadal działa dodatkowe ostrzeżenie o możliwym duplikacie.

## Zmiany v0.5.7

- Przycisk GPS na mapie pokazuje aktualną lokalizację użytkownika na mapie.
- Funkcje GPS proszą o włączenie lokalizacji albo nadanie zgody.
- Zakładka `Blisko` ma przyciski promienia zamiast wadliwej listy rozwijanej.
- Zakładka `Blisko` automatycznie próbuje pobrać GPS i synchronizuje dane.
- Usunięto błąd `DateFormat('pl_PL')`, który mógł powodować szare/puste ekrany w czyszczeniu i kontroli.

## Zmiany v0.5.8

- Poprawiono układ listy `Budki do wyczyszczenia`.
- Nazwa budki nie jest już ściskana po jednej literze w pionie.
- Przycisk `Wpisz czyszczenie` jest pod opisem, a nie wciskany z prawej strony.
- Poprawiono też wygląd sekcji `Budki wyczyszczone`.


## Zmiany v0.6.1

- Naprawiono okno logowania/rejestracji: pola email i hasło są widoczne także po otwarciu klawiatury.
- Dodano przycisk „Nie pamiętasz hasła?” i ekran ustawiania nowego hasła.
- Poprawiono logowanie Google OAuth przez Supabase.
- Dodano czytelniejsze komunikaty błędów logowania.

## Zmiany v0.5.9

- Poprawiono zakładkę `Czyszczenie`.
- Gość może oglądać obiekty, ale nie może dodawać, edytować, zgłaszać ani wpisywać kontroli/czyszczenia.
- Dodano szybkie dodawanie zdjęć do istniejących budek z poziomu szczegółów obiektu.
- Zmieniono ikony typów obiektów.
- Budki wyczyszczone mają zielony znacznik, a budki do naprawy czerwony znacznik.

## Wersja 0.6.1 — mapa obserwacji ptaków

Dodano jedną aplikację z oddzielną zakładką **Ptaki** oraz formularzem **Dodaj**.

Funkcje:

- osobna mapa obserwacji ptaków,
- import publicznych zgłoszeń z Clanga,
- dodawanie własnych obserwacji z GPS,
- dodawanie zdjęć lokalnie,
- status obserwacji: nadal obserwowany / nie ma / nie wiadomo,
- potwierdzenie obserwacji przez innych: „Też widziałem”,
- panel admina dla gatunków wrażliwych,
- dostęp do dokładnych lokalizacji po emailu i po konkretnym gatunku,
- eksport obserwacji do CSV/KML przez panel admina.

Po aktualizacji uruchom w Supabase aktualny plik `supabase/schema.sql`.
