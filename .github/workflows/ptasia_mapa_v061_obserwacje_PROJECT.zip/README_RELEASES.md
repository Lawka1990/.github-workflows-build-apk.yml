# Wydawanie nowych wersji przez GitHub Releases

Ta wersja workflow robi automatycznie:

1. buduje APK,
2. tworzy GitHub Release, np. `v1.4.0`,
3. wrzuca APK do Release,
4. aktualizuje plik `update/latest.json` w repozytorium,
5. aplikacja przy starcie sprawdza `latest.json` i informuje użytkownika o nowej wersji.

## Jak wydać nową wersję

1. W `pubspec.yaml` zwiększ wersję, np.:

```yaml
version: 1.5.0+150
```

2. W `update/latest.json` możesz zostawić stare dane — workflow i tak nadpisze go po zbudowaniu.
3. Wrzuć ZIP do GitHuba jako:

```text
ptasia_mapa_clean_rewrite_v14_releases.zip
```

4. Uruchom workflow albo zrób commit.

## Ważne dla aktualizacji bez odinstalowania

Android zaktualizuje APK tylko gdy:

- `applicationId` jest taki sam,
- `versionCode` jest większy,
- APK jest podpisany tym samym kluczem.

Dlatego najlepiej ustaw stały klucz podpisu w GitHub Secrets:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Bez stałego podpisu Android może wymagać odinstalowania starej wersji.

## Link do aktualizacji

Workflow domyślnie wbudowuje w aplikację link:

```text
https://raw.githubusercontent.com/OWNER/REPO/main/update/latest.json
```

Jeśli używasz gałęzi `master`, workflow sam użyje `master`.
