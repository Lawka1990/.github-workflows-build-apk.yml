# Aktualizacje APK

Android nie pozwala zwykłej aplikacji na cichą instalację aktualizacji.
Aplikacja może sprawdzić wersję, pokazać komunikat i otworzyć link do pobrania APK. Użytkownik potwierdza instalację w Androidzie.

## Sekrety GitHub

- `APP_UPDATE_JSON_URL` — link do pliku JSON z informacją o wersji.
- `APP_UPDATE_APK_URL` — bezpośredni link do APK, jeśli nie używasz JSON.

## Format latest.json

```json
{
  "versionCode": 131,
  "versionName": "1.3.1",
  "apkUrl": "https://twoj-serwer.pl/ptasia-mapa.apk",
  "notes": "Opis zmian."
}
```

`versionCode` musi być większy niż obecny build aplikacji.

## Żeby aktualizacja nadpisała starą aplikację

Muszą być spełnione 3 warunki:

1. taki sam `applicationId`,
2. wyższy `versionCode`,
3. APK podpisany tym samym kluczem co poprzednia wersja.

Jeżeli podpis będzie inny, Android odmówi aktualizacji.
