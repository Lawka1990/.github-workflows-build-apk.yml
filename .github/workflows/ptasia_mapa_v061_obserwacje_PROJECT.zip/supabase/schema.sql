
create extension if not exists "uuid-ossp";

create table if not exists public.app_profiles (
  id bigserial primary key,
  user_id uuid unique,
  email text unique,
  role text not null default 'user',
  created_at timestamptz not null default now()
);

create table if not exists public.nest_sites (
  id uuid primary key,
  name text not null,
  type text not null default 'Budka lęgowa',
  latitude double precision not null,
  longitude double precision not null,
  place_description text not null default '',
  technical_status text not null default 'Dobry',
  repair_needed boolean not null default false,
  damage_description text not null default '',
  notes text not null default '',
  report_status text not null default 'Zgłoszona',
  delete_requested boolean not null default false,
  delete_reason text not null default '',
  hidden_from_users boolean not null default false,
  deleted boolean not null default false,
  owner_id text not null default '',
  owner_email text not null default '',
  photo_urls jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.inspections (
  id uuid primary key,
  nest_site_id uuid not null references public.nest_sites(id) on delete cascade,
  date timestamptz not null,
  inspector text not null default '',
  cleaned boolean not null default false,
  cleaned_by text not null default '',
  condition text not null default 'Dobry',
  birds_present boolean not null default false,
  bird_species text not null default '',
  eggs_count integer not null default 0,
  chicks_count integer not null default 0,
  adults_count integer not null default 0,
  notes text not null default '',
  deleted boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.nest_sites add column if not exists delete_requested boolean not null default false;
alter table public.nest_sites add column if not exists delete_reason text not null default '';
alter table public.nest_sites add column if not exists hidden_from_users boolean not null default false;
alter table public.nest_sites add column if not exists owner_id text not null default '';
alter table public.nest_sites add column if not exists owner_email text not null default '';
alter table public.nest_sites add column if not exists notes text not null default '';
alter table public.nest_sites add column if not exists photo_urls jsonb not null default '[]'::jsonb;

alter table public.app_profiles enable row level security;
alter table public.nest_sites enable row level security;
alter table public.inspections enable row level security;

drop policy if exists "profiles all anon authenticated" on public.app_profiles;
drop policy if exists "nest sites all anon authenticated" on public.nest_sites;
drop policy if exists "inspections all anon authenticated" on public.inspections;

create policy "profiles all anon authenticated"
on public.app_profiles for all
to anon, authenticated
using (true)
with check (true);

create policy "nest sites all anon authenticated"
on public.nest_sites for all
to anon, authenticated
using (true)
with check (true);

create policy "inspections all anon authenticated"
on public.inspections for all
to anon, authenticated
using (true)
with check (true);

create index if not exists nest_sites_owner_idx on public.nest_sites(owner_id);
create index if not exists nest_sites_updated_idx on public.nest_sites(updated_at desc);
create index if not exists inspections_site_idx on public.inspections(nest_site_id);

-- =========================================================
-- Ptasia Mapa v0.6.1 — osobna mapa obserwacji ptaków
-- =========================================================

create table if not exists public.bird_observations (
  id uuid primary key,
  species_name text not null,
  species_name_en text not null default '',
  latin_name text not null default '',
  bird_group text not null default '',
  count integer not null default 1,
  location_name text not null default '',
  lat_public double precision not null,
  lng_public double precision not null,
  observed_at timestamptz not null default now(),
  source text not null default 'user' check (source in ('user', 'clanga')),
  source_url text not null default '',
  observer_name text not null default '',
  status text not null default 'unknown' check (status in ('active', 'not_seen', 'unknown')),
  is_sensitive boolean not null default false,
  location_resolved boolean not null default true,
  location_accuracy text not null default 'GPS',
  owner_id text not null default '',
  owner_email text not null default '',
  photo_urls jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.bird_observation_exact_locations (
  observation_id uuid primary key references public.bird_observations(id) on delete cascade,
  species_name text not null,
  latitude double precision not null,
  longitude double precision not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.bird_observation_confirmations (
  id uuid primary key,
  observation_id uuid not null references public.bird_observations(id) on delete cascade,
  user_email text not null default '',
  display_name text not null default '',
  seen_at timestamptz not null default now(),
  still_present boolean,
  comment text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.bird_sensitive_species (
  species_name text primary key,
  created_at timestamptz not null default now()
);

create table if not exists public.bird_sensitive_access (
  email text not null,
  species_name text not null,
  created_at timestamptz not null default now(),
  primary key (email, species_name)
);

alter table public.bird_observations enable row level security;
alter table public.bird_observation_exact_locations enable row level security;
alter table public.bird_observation_confirmations enable row level security;
alter table public.bird_sensitive_species enable row level security;
alter table public.bird_sensitive_access enable row level security;

drop policy if exists bird_observations_select_all on public.bird_observations;
create policy bird_observations_select_all on public.bird_observations
for select to anon, authenticated
using (true);

drop policy if exists bird_observations_insert_logged on public.bird_observations;
create policy bird_observations_insert_logged on public.bird_observations
for insert to authenticated
with check (true);

drop policy if exists bird_observations_update_owner_admin on public.bird_observations;
create policy bird_observations_update_owner_admin on public.bird_observations
for update to authenticated
using (
  owner_id = auth.uid()::text
  or owner_email = coalesce(auth.jwt() ->> 'email', '')
  or exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
)
with check (
  owner_id = auth.uid()::text
  or owner_email = coalesce(auth.jwt() ->> 'email', '')
  or exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
);

drop policy if exists bird_exact_select_allowed on public.bird_observation_exact_locations;
create policy bird_exact_select_allowed on public.bird_observation_exact_locations
for select to authenticated
using (
  exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
  or exists (
    select 1 from public.bird_sensitive_access a
    where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', ''))
    and (a.species_name = '*' or lower(a.species_name) = lower(bird_observation_exact_locations.species_name))
  )
);

drop policy if exists bird_exact_insert_logged on public.bird_observation_exact_locations;
create policy bird_exact_insert_logged on public.bird_observation_exact_locations
for insert to authenticated
with check (true);

drop policy if exists bird_exact_update_allowed on public.bird_observation_exact_locations;
create policy bird_exact_update_allowed on public.bird_observation_exact_locations
for update to authenticated
using (
  exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
)
with check (
  exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
);

drop policy if exists bird_confirmations_select_all on public.bird_observation_confirmations;
create policy bird_confirmations_select_all on public.bird_observation_confirmations
for select to anon, authenticated
using (true);

drop policy if exists bird_confirmations_insert_logged on public.bird_observation_confirmations;
create policy bird_confirmations_insert_logged on public.bird_observation_confirmations
for insert to authenticated
with check (true);

drop policy if exists bird_sensitive_species_select_all on public.bird_sensitive_species;
create policy bird_sensitive_species_select_all on public.bird_sensitive_species
for select to anon, authenticated
using (true);

drop policy if exists bird_sensitive_species_admin_write on public.bird_sensitive_species;
create policy bird_sensitive_species_admin_write on public.bird_sensitive_species
for all to authenticated
using (
  exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
)
with check (
  exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
);

drop policy if exists bird_sensitive_access_admin_read on public.bird_sensitive_access;
create policy bird_sensitive_access_admin_read on public.bird_sensitive_access
for select to authenticated
using (
  lower(email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  or exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
);

drop policy if exists bird_sensitive_access_admin_write on public.bird_sensitive_access;
create policy bird_sensitive_access_admin_write on public.bird_sensitive_access
for all to authenticated
using (
  exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
)
with check (
  exists (
    select 1 from public.app_profiles p
    where p.user_id = auth.uid()
    and p.role in ('admin', 'super_admin')
  )
);

insert into public.bird_sensitive_species (species_name)
values
  ('Puchacz'),
  ('Sóweczka'),
  ('Włochatka'),
  ('Orlik krzykliwy'),
  ('Orlik grubodzioby'),
  ('Bielik'),
  ('Rybołów'),
  ('Bocian czarny'),
  ('Głuszec'),
  ('Cietrzew')
on conflict (species_name) do nothing;
