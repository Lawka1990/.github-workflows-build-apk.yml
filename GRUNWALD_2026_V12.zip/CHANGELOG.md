# Historia zmian

## 0.12.0+13 — V12

### Dodano

- orientacyjne prowadzenie do punktu po głównych drogach planu,
- przybliżoną długość i automatyczne kadrowanie trasy,
- filtrowanie kategorii znaczników na mapie,
- wyszukiwarkę miejsc bez rozróżniania polskich znaków,
- szczegółowe panele miejsc i wydarzeń,
- ulubione wydarzenia zapisywane lokalnie,
- filtry programu według dnia i kategorii,
- wybór kategorii, ikony i koloru w edytorze punktów,
- widoczny stan administratora i szybkie wyłączenie trybu,
- testy nawigacji oraz wyszukiwania,
- zapis APK/AAB również jako GitHub Artifact.

### Poprawiono

- trwałe zapisywanie zmian opisów wbudowanych punktów,
- zachowanie wybranego celu pomimo filtrowania mapy,
- komunikaty błędów lokalizacji i przejście do ustawień,
- usuwanie nieaktualnego znacznika po wyjściu poza obszar mapy,
- wybór właściwego dnia programu przed i po wydarzeniu,
- ekran „Teraz” po zakończeniu Dni Grunwaldu,
- kontrast okien dialogowych i rozwijanych list,
- dostępność znaczników dla czytników ekranu.

### Zachowano

- dane i kotwice V11,
- mapę 1536 × 1024,
- pakiet `pl.grunwald.grunwald_navigator`,
- PIN administratora `1410`.
